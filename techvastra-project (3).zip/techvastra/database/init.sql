-- Optional. The backend creates the database and all tables automatically on first run.
CREATE DATABASE IF NOT EXISTS techvastra CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
