import { createContext, useContext, useState } from 'react';

const Ctx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('tv_user')); } catch (e) { return null; }
  });
  const signIn = (data) => {
    localStorage.setItem('tv_token', data.token);
    localStorage.setItem('tv_user', JSON.stringify(data.user));
    setUser(data.user);
  };
  const signOut = () => {
    localStorage.removeItem('tv_token');
    localStorage.removeItem('tv_user');
    setUser(null);
  };
  return <Ctx.Provider value={{ user, signIn, signOut }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
export const homeFor = (user) => (user && user.role === 'TAILOR' ? '/tailor' : '/customer');
