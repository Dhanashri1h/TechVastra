import { useEffect, useRef, useState } from 'react';

const mmss = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

export default function Recorder({ onChange }) {
  const [state, setState] = useState('idle');
  const [url, setUrl] = useState(null);
  const [secs, setSecs] = useState(0);
  const [err, setErr] = useState('');
  const rec = useRef(null);
  const chunks = useRef([]);
  const timer = useRef(null);

  useEffect(() => () => clearInterval(timer.current), []);

  async function start() {
    setErr('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunks.current = [];
      mr.ondataavailable = (e) => { if (e.data.size) chunks.current.push(e.data); };
      mr.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        clearInterval(timer.current);
        const blob = new Blob(chunks.current, { type: mr.mimeType || 'audio/webm' });
        setUrl(URL.createObjectURL(blob));
        setState('done');
        onChange(blob);
      };
      mr.start();
      rec.current = mr;
      setSecs(0);
      timer.current = setInterval(() => setSecs((s) => s + 1), 1000);
      setState('rec');
    } catch (e) {
      setErr('The microphone is blocked or unavailable. Allow microphone access in your browser and try again.');
    }
  }

  function stop() { if (rec.current && rec.current.state !== 'inactive') rec.current.stop(); }
  function remove() { setUrl(null); setState('idle'); setSecs(0); onChange(null); }

  return (
    <div className="recorder">
      {state === 'idle' && <button type="button" className="btn secondary" onClick={start}>Start recording</button>}
      {state === 'rec' && (
        <>
          <span className="rec-dot" aria-hidden="true" />
          <strong>Recording {mmss(secs)}</strong>
          <button type="button" className="btn" onClick={stop}>Stop recording</button>
        </>
      )}
      {state === 'done' && (
        <>
          <audio controls src={url} />
          <button type="button" className="btn small secondary" onClick={remove}>Remove and record again</button>
        </>
      )}
      {err && <p className="error" role="alert">{err}</p>}
    </div>
  );
}
