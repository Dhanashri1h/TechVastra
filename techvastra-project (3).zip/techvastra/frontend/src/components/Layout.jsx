import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Navigate, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import { api } from '../api.js';

export default function Layout() {
  const { user, signOut } = useAuth();
  const nav = useNavigate();
  const [unread, setUnread] = useState(0);
  const [toast, setToast] = useState(null);
  const prev = useRef(null);

  useEffect(() => {
    if (!user) return undefined;
    let alive = true;
    const poll = async () => {
      try {
        const d = await api.get('/notifications');
        if (!alive) return;
        if (prev.current !== null && d.unread > prev.current && d.items.length) {
          setToast(d.items[0]);
          setTimeout(() => alive && setToast(null), 7000);
        }
        prev.current = d.unread;
        setUnread(d.unread);
      } catch (e) { /* ignore */ }
    };
    poll();
    const id = setInterval(poll, 8000);
    window.addEventListener('tv-notif', poll);
    return () => {
      alive = false;
      clearInterval(id);
      window.removeEventListener('tv-notif', poll);
    };
  }, [user]);

  if (!user) return <Navigate to="/auth" replace />;

  const links = user.role === 'TAILOR'
    ? [['/tailor', 'Requests'], ['/tailor/profile', 'Profile and calendar']]
    : [['/customer', 'Find a tailor'], ['/orders', 'My orders']];

  return (
    <div className="shell">
      <header className="topbar">
        <Link to={user.role === 'TAILOR' ? '/tailor' : '/customer'} className="brand">Techvastra</Link>
        <nav className="nav" aria-label="Main">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end className={({ isActive }) => (isActive ? 'active' : '')}>{label}</NavLink>
          ))}
          <NavLink to="/notifications" className={({ isActive }) => 'bell' + (isActive ? ' active' : '')}>
            Notifications{unread > 0 && <span className="count">{unread}</span>}
          </NavLink>
        </nav>
        <div className="who">
          <span>{user.role === 'TAILOR' ? user.shopName || user.name : user.name}</span>
          <button className="linkbtn" onClick={() => { signOut(); nav('/'); }}>Sign out</button>
        </div>
      </header>
      <main><Outlet /></main>
      {toast && (
        <button className="toast" onClick={() => { setToast(null); nav(toast.orderId ? '/orders/' + toast.orderId : '/notifications'); }}>
          <strong>New notification</strong>
          <span>{toast.message}</span>
        </button>
      )}
    </div>
  );
}
