import { useState } from 'react';

const pad = (n) => String(n).padStart(2, '0');
const key = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;
const todayKey = () => {
  const t = new Date();
  return key(t.getFullYear(), t.getMonth(), t.getDate());
};
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/**
 * mode "view": shows free days only.  mode "pick": customer picks a free day.  mode "edit": tailor toggles free days.
 */
export default function Calendar({ free = [], mode = 'view', selected, onPick }) {
  const now = new Date();
  const [cur, setCur] = useState({ y: now.getFullYear(), m: now.getMonth() });
  const freeSet = new Set(free);
  const lead = new Date(cur.y, cur.m, 1).getDay();
  const total = new Date(cur.y, cur.m + 1, 0).getDate();
  const today = todayKey();
  const cells = [...Array(lead).fill(null), ...Array.from({ length: total }, (_, i) => i + 1)];
  const atStart = cur.y === now.getFullYear() && cur.m === now.getMonth();

  const move = (delta) => {
    const d = new Date(cur.y, cur.m + delta, 1);
    setCur({ y: d.getFullYear(), m: d.getMonth() });
  };

  return (
    <div className="cal">
      <div className="cal-head">
        <button type="button" className="btn small secondary" onClick={() => move(-1)} disabled={atStart} aria-label="Previous month">Previous</button>
        <strong>{MONTHS[cur.m]} {cur.y}</strong>
        <button type="button" className="btn small secondary" onClick={() => move(1)} aria-label="Next month">Next</button>
      </div>
      <div className="cal-grid" role="grid">
        {DOW.map((d) => <div key={d} className="dow">{d}</div>)}
        {cells.map((d, i) => {
          if (d === null) return <div key={'e' + i} />;
          const k = key(cur.y, cur.m, d);
          const past = k < today;
          const isFree = freeSet.has(k);
          const clickable = !past && (mode === 'edit' || (mode === 'pick' && isFree));
          const cls = ['day', past ? 'past' : '', isFree ? 'free' : 'busy', selected === k ? 'sel' : ''].join(' ');
          return (
            <button
              key={k}
              type="button"
              className={cls}
              disabled={!clickable}
              onClick={() => onPick && onPick(k)}
              aria-label={`${d} ${MONTHS[cur.m]}, ${past ? 'past' : isFree ? 'free' : 'not available'}`}
            >
              {d}
            </button>
          );
        })}
      </div>
      <div className="legend">
        <span><i className="sw free" /> Free to take orders</span>
        <span><i className="sw busy" /> Not available</span>
        {mode === 'pick' && <span><i className="sw sel" /> Your choice</span>}
      </div>
    </div>
  );
}
