import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import Calendar from '../components/Calendar.jsx';
import { fmtShort, to12h } from '../util.js';

export default function TailorView() {
  const { id } = useParams();
  const nav = useNavigate();
  const { state } = useLocation();
  const [t, setT] = useState(null);
  const [err, setErr] = useState('');
  const [zoom, setZoom] = useState(null);

  useEffect(() => { api.get('/tailors/' + id).then(setT).catch((e) => setErr(e.message)); }, [id]);

  if (err) return <div className="page"><p className="error">{err}</p></div>;
  if (!t) return <div className="page"><p className="muted">Loading profile</p></div>;

  return (
    <div className="page">
      <Link to="/customer" className="back">Back to the assistant</Link>

      <section className="hero-block">
        <div>
          <h1>{t.shopName}</h1>
          <p>{t.ownerName}, {t.address || t.area}</p>
          {t.specialties.length > 0 && <p className="tags light">{t.specialties.map((s) => <span key={s}>{s}</span>)}</p>}
        </div>
        <button className="btn light" onClick={() => nav(`/customer/tailors/${t.id}/order`, { state })}>Request an order</button>
      </section>

      <section className="stats">
        <div><strong>{t.rating > 0 ? t.rating.toFixed(1) : 'New'}</strong><span>Rating</span></div>
        <div><strong>{t.experienceYears}</strong><span>Years of experience</span></div>
        <div><strong>{t.completedOrders}</strong><span>Orders completed</span></div>
        <div><strong>{t.activeOrders}</strong><span>Orders in progress now</span></div>
      </section>

      <div className="cols">
        <div>
          <h2>About</h2>
          <p>{t.bio || 'This tailor has not added a description yet.'}</p>

          <h2>Work gallery</h2>
          {t.gallery.length === 0 ? <p className="muted">No photos yet.</p> : (
            <div className="gallery">
              {t.gallery.map((g) => (
                <button key={g.id} className="gal" onClick={() => setZoom(g)} aria-label={'Open photo: ' + g.caption}>
                  <img src={g.url} alt={g.caption} loading="lazy" />
                  <span>{g.caption}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <aside>
          <div className="card">
            <h3>Order receiving hours</h3>
            <p>{to12h(t.openTime)} to {to12h(t.closeTime)}</p>
            <p className="muted">{t.workingDays}</p>
            <h3>Address</h3>
            <p>{t.address || t.area}</p>
            <p className="muted">Contact number is shared after the tailor accepts your request.</p>
          </div>
          <div className="card">
            <h3>Availability calendar</h3>
            <Calendar free={t.freeDates} mode="view" />
            {t.freeDates[0] && <p className="muted">Next free date: {fmtShort(t.freeDates[0])}</p>}
          </div>
        </aside>
      </div>

      {zoom && (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label={zoom.caption} onClick={() => setZoom(null)}>
          <img src={zoom.url} alt={zoom.caption} />
          <button className="btn light">Close</button>
        </div>
      )}
    </div>
  );
}
