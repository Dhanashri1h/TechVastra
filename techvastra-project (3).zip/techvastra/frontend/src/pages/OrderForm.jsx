import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import Calendar from '../components/Calendar.jsx';
import Recorder from '../components/Recorder.jsx';
import { fmtDate } from '../util.js';

export default function OrderForm() {
  const { id } = useParams();
  const { state } = useLocation();
  const nav = useNavigate();
  const [t, setT] = useState(null);
  const [f, setF] = useState({ garment: state?.garment || '', notes: '', fabricDetails: '', measurements: '' });
  const [date, setDate] = useState('');
  const [audio, setAudio] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  useEffect(() => { api.get('/tailors/' + id).then(setT).catch((e) => setErr(e.message)); }, [id]);

  async function submit(e) {
    e.preventDefault();
    setErr('');
    if (!f.garment.trim()) return setErr('Tell the tailor what you need stitched.');
    if (!date) return setErr('Pick the date you need it by from the calendar.');
    const form = new FormData();
    form.append('tailorId', id);
    form.append('garment', f.garment);
    form.append('dueDate', date);
    form.append('notes', f.notes);
    form.append('fabricDetails', f.fabricDetails);
    form.append('measurements', f.measurements);
    if (audio) form.append('audio', audio, audio.type.includes('mp4') ? 'voice-note.m4a' : 'voice-note.webm');
    setBusy(true);
    try {
      const o = await api.upload('/orders', form);
      nav('/orders/' + o.id, { replace: true });
    } catch (ex) {
      setErr(ex.message);
      setBusy(false);
    }
  }

  if (!t) return <div className="page">{err ? <p className="error">{err}</p> : <p className="muted">Loading</p>}</div>;

  return (
    <div className="page narrow">
      <Link to={'/customer/tailors/' + id} className="back">Back to {t.shopName}</Link>
      <h1>Request an order from {t.shopName}</h1>
      <p className="muted">The tailor is notified straight away. Once they accept, you can see their contact number and follow each stage.</p>

      <form onSubmit={submit} className="stack">
        <label className="field">What do you need stitched
          <input className="input" value={f.garment} onChange={set('garment')} placeholder="For example, bridal blouse" required />
        </label>

        <div className="field">
          Date you need it by
          <Calendar free={t.freeDates} mode="pick" selected={date} onPick={setDate} />
          <p className="muted">{date ? 'Selected: ' + fmtDate(date) : 'Only the tailor\'s free dates can be selected.'}</p>
        </div>

        <label className="field">Fabric details
          <textarea className="input" rows="3" value={f.fabricDetails} onChange={set('fabricDetails')} placeholder="Type of fabric, colour, quantity in metres, who supplies it" />
        </label>
        <label className="field">Measurements
          <textarea className="input" rows="3" value={f.measurements} onChange={set('measurements')} placeholder="Bust, waist, shoulder, sleeve length, or say that you will visit for measurements" />
        </label>
        <label className="field">Design notes
          <textarea className="input" rows="4" value={f.notes} onChange={set('notes')} placeholder="Neck style, sleeves, back design, lining, embroidery, anything the tailor should know" />
        </label>

        <div className="field">
          Voice note (optional)
          <p className="muted">Prefer to explain it by speaking? Record every detail of your order here.</p>
          <Recorder onChange={setAudio} />
        </div>

        {err && <p className="error" role="alert">{err}</p>}
        <button className="btn wide" disabled={busy}>{busy ? 'Sending request' : 'Send request to tailor'}</button>
      </form>
    </div>
  );
}
