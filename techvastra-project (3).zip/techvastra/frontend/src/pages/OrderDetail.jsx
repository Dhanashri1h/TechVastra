import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { fmtDate, fmtDateTime, statusLabel } from '../util.js';

export default function OrderDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const isTailor = user.role === 'TAILOR';
  const [o, setO] = useState(null);
  const [err, setErr] = useState('');
  const [stage, setStage] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try { setO(await api.get('/orders/' + id)); } catch (e) { setErr(e.message); }
  }, [id]);

  useEffect(() => {
    load();
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    if (o && o.status === 'ACCEPTED') {
      const next = o.stages[Math.min(o.stages.indexOf(o.stage) + 1, o.stages.length - 1)];
      setStage((s) => s || next);
    }
  }, [o]);

  async function act(path, body) {
    setBusy(true);
    setErr('');
    try {
      await api.post(`/orders/${id}/${path}`, body);
      setNote('');
      setStage('');
      await load();
      window.dispatchEvent(new Event('tv-notif'));
    } catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  }

  if (!o) return <div className="page">{err ? <p className="error">{err}</p> : <p className="muted">Loading order</p>}</div>;

  const reached = o.status === 'COMPLETED' ? o.stages.length - 1 : o.status === 'ACCEPTED' ? o.stages.indexOf(o.stage) : -1;
  const back = isTailor ? '/tailor' : '/orders';

  return (
    <div className="page">
      <Link to={back} className="back">{isTailor ? 'Back to requests' : 'Back to my orders'}</Link>

      <section className="hero-block">
        <div>
          <h1>{o.garment}</h1>
          <p>{isTailor ? `For ${o.customerName}, ${o.customerCity}` : `With ${o.shopName}`}</p>
          <p>Needed by {fmtDate(o.dueDate)}</p>
        </div>
        <span className="badge light">{statusLabel(o.status, isTailor)}</span>
      </section>

      {err && <p className="error" role="alert">{err}</p>}

      <div className="cols">
        <div>
          <h2>Progress</h2>
          {o.status === 'REQUESTED' && <p className="muted">{isTailor ? 'Accept this request to start the order.' : 'Your request has been sent. You will be notified as soon as the tailor responds.'}</p>}
          {o.status === 'REJECTED' && <p className="muted">{isTailor ? 'You declined this request.' : 'The tailor could not take this order. Go back to the assistant and choose another tailor.'}</p>}
          {(o.status === 'ACCEPTED' || o.status === 'COMPLETED') && (
            <>
              <div className="bar big" aria-label={o.progress + ' percent complete'}><i style={{ width: o.progress + '%' }} /></div>
              <ol className="tracker">
                {o.stages.map((s, i) => (
                  <li key={s} className={i < reached || o.status === 'COMPLETED' ? 'done' : i === reached ? 'current' : ''}>
                    <span className="dot" />{s}
                  </li>
                ))}
                <li className={o.status === 'COMPLETED' ? 'done' : ''}><span className="dot" />Order completed</li>
              </ol>
            </>
          )}

          {isTailor && o.status === 'REQUESTED' && (
            <div className="actions">
              <button className="btn" disabled={busy} onClick={() => act('accept')}>Accept request</button>
              <button className="btn secondary" disabled={busy} onClick={() => act('reject', {})}>Decline</button>
            </div>
          )}

          {isTailor && o.status === 'ACCEPTED' && (
            <div className="card">
              <h3>Update the customer</h3>
              <label className="field">New stage
                <select className="input" value={stage} onChange={(e) => setStage(e.target.value)}>
                  {o.stages.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </label>
              <label className="field">Note for the customer (optional)
                <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="For example, trial fitting is possible tomorrow" />
              </label>
              <div className="actions">
                <button className="btn" disabled={busy || !stage} onClick={() => act('status', { stage, note })}>Update status</button>
                <button className="btn secondary" disabled={busy}
                  onClick={() => window.confirm('End this order? The customer will be told that stitching is complete.') && act('complete')}>
                  End order as completed
                </button>
              </div>
            </div>
          )}

          <h2>History</h2>
          <ul className="timeline">
            {[...o.updates].reverse().map((u, i) => (
              <li key={i}>
                <strong>{u.stage}</strong>
                <span className="muted">{fmtDateTime(u.createdAt)}</span>
                {u.note && <p>{u.note}</p>}
              </li>
            ))}
          </ul>
        </div>

        <aside>
          <div className="card">
            <h3>Contact</h3>
            {o.contactVisible ? (
              isTailor
                ? <p>{o.customerName}<br /><strong>{o.customerMobile}</strong></p>
                : <p>{o.shopName}<br /><strong>{o.tailorMobile}</strong><br />{o.tailorAddress}</p>
            ) : <p className="muted">The contact number appears here once the order is accepted.</p>}
          </div>
          <div className="card">
            <h3>Order details</h3>
            <dl className="stack-dl">
              <dt>Fabric</dt><dd>{o.fabricDetails || 'Not specified'}</dd>
              <dt>Measurements</dt><dd>{o.measurements || 'Not specified'}</dd>
              <dt>Design notes</dt><dd>{o.notes || 'None'}</dd>
              <dt>Requested on</dt><dd>{fmtDateTime(o.createdAt)}</dd>
            </dl>
            {o.audioUrl && (<><h3>Voice note</h3><audio controls src={o.audioUrl} /></>)}
          </div>
        </aside>
      </div>
    </div>
  );
}
