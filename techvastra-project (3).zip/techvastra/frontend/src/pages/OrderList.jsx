import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { fmtDate, statusLabel } from '../util.js';

export default function OrderList() {
  const { user } = useAuth();
  const isTailor = user.role === 'TAILOR';
  const tabs = isTailor
    ? [['REQUESTED', 'New requests'], ['ACCEPTED', 'In progress'], ['COMPLETED', 'Completed'], ['REJECTED', 'Declined']]
    : [['ALL', 'All orders'], ['REQUESTED', 'Waiting'], ['ACCEPTED', 'In progress'], ['COMPLETED', 'Completed'], ['REJECTED', 'Declined']];
  const [tab, setTab] = useState(tabs[0][0]);
  const [orders, setOrders] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(0);

  const load = useCallback(() => api.get('/orders').then(setOrders).catch((e) => setErr(e.message)), []);
  useEffect(() => {
    load();
    const id = setInterval(load, 10000);
    return () => clearInterval(id);
  }, [load]);

  async function answer(o, action) {
    setBusy(o.id);
    setErr('');
    try { await api.post(`/orders/${o.id}/${action}`); await load(); }
    catch (e) { setErr(e.message); }
    finally { setBusy(0); }
  }

  if (!orders) return <div className="page">{err ? <p className="error">{err}</p> : <p className="muted">Loading orders</p>}</div>;
  const shown = tab === 'ALL' ? orders : orders.filter((o) => o.status === tab);
  const count = (k) => (k === 'ALL' ? orders.length : orders.filter((o) => o.status === k).length);

  return (
    <div className="page">
      <h1>{isTailor ? 'Stitching requests' : 'My orders'}</h1>
      <p className="muted">{isTailor ? 'Every request shows the customer\'s notes, fabric, measurements and voice note.' : 'Track each order from request to delivery.'}</p>

      <div className="tabs" role="tablist">
        {tabs.map(([k, label]) => (
          <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>
            {label} <span className="n">{count(k)}</span>
          </button>
        ))}
      </div>
      {err && <p className="error" role="alert">{err}</p>}

      {shown.length === 0 && (
        <div className="empty">
          <p>{isTailor ? 'No requests in this list.' : 'No orders in this list yet.'}</p>
          {!isTailor && <Link className="btn" to="/customer">Find a tailor</Link>}
        </div>
      )}

      <div className="olist">
        {shown.map((o) => (
          <article key={o.id} className="ocard">
            <header>
              <div>
                <h3>{o.garment}</h3>
                <p className="muted">{isTailor ? `${o.customerName}, ${o.customerCity}` : o.shopName}</p>
              </div>
              <span className={'badge ' + (o.status === 'REQUESTED' ? 'outline' : 'solid')}>{statusLabel(o.status, isTailor)}</span>
            </header>

            <dl className="facts">
              <div><dt>Needed by</dt><dd>{fmtDate(o.dueDate)}</dd></div>
              <div><dt>Current stage</dt><dd>{o.stage}</dd></div>
              {isTailor && o.contactVisible && <div><dt>Customer mobile</dt><dd>{o.customerMobile}</dd></div>}
            </dl>

            {isTailor && (o.status === 'REQUESTED' || o.status === 'ACCEPTED') && (
              <div className="notes">
                {o.notes && <p><strong>Design notes</strong> {o.notes}</p>}
                {o.fabricDetails && <p><strong>Fabric</strong> {o.fabricDetails}</p>}
                {o.measurements && <p><strong>Measurements</strong> {o.measurements}</p>}
                {o.audioUrl && <div><strong>Voice note</strong><audio controls src={o.audioUrl} /></div>}
              </div>
            )}

            {o.status === 'ACCEPTED' && <div className="bar" aria-label={o.progress + ' percent complete'}><i style={{ width: o.progress + '%' }} /></div>}

            <footer>
              <Link className="btn small secondary" to={'/orders/' + o.id}>Open order</Link>
              {isTailor && o.status === 'REQUESTED' && (
                <>
                  <button className="btn small" disabled={busy === o.id} onClick={() => answer(o, 'accept')}>Accept request</button>
                  <button className="btn small secondary" disabled={busy === o.id} onClick={() => answer(o, 'reject')}>Decline</button>
                </>
              )}
            </footer>
          </article>
        ))}
      </div>
    </div>
  );
}
