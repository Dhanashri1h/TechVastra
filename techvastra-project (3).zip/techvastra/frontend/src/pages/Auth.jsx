import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth, homeFor } from '../AuthContext.jsx';
import { AREAS } from '../areas.js';

export default function Auth() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { signIn } = useAuth();
  const [mode, setMode] = useState(params.get('mode') === 'register' ? 'register' : 'login');
  const [role, setRole] = useState(params.get('role') === 'TAILOR' ? 'TAILOR' : 'CUSTOMER');
  const [f, setF] = useState({ name: '', email: '', password: '', mobile: '', city: '', shopName: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setErr('');
    setBusy(true);
    try {
      const data = mode === 'register'
        ? await api.post('/auth/register', { ...f, role })
        : await api.post('/auth/login', { email: f.email, password: f.password });
      signIn(data);
      nav(homeFor(data.user), { replace: true });
    } catch (ex) {
      setErr(ex.message);
    } finally {
      setBusy(false);
    }
  }

  const isTailor = role === 'TAILOR';
  return (
    <div className="auth">
      <aside className="auth-side">
        <Link to="/" className="brand">Techvastra</Link>
        <div>
          <h1>{mode === 'login' ? 'Sign in' : isTailor ? 'Register your shop' : 'Create your account'}</h1>
          <p className="lead">
            {mode === 'login'
              ? 'Use the email and password you registered with. You will land in your customer or tailor workspace automatically.'
              : isTailor
                ? 'Customers in your area will find your shop, see your work and send you orders.'
                : 'Find tailors in your area, send an order request and follow it until it is ready.'}
          </p>
        </div>
        <p className="fine">Demo accounts: customer@techvastra.com or tailor1@techvastra.com, password: password123</p>
      </aside>
      <form className="auth-form" onSubmit={submit} noValidate>
        <div className="seg" role="tablist" aria-label="Sign in or register">
          <button type="button" role="tab" aria-selected={mode === 'login'} className={mode === 'login' ? 'on' : ''} onClick={() => setMode('login')}>Sign in</button>
          <button type="button" role="tab" aria-selected={mode === 'register'} className={mode === 'register' ? 'on' : ''} onClick={() => setMode('register')}>Register</button>
        </div>

        {mode === 'register' && (
          <div className="seg" role="radiogroup" aria-label="Account type">
            <button type="button" role="radio" aria-checked={!isTailor} className={!isTailor ? 'on' : ''} onClick={() => setRole('CUSTOMER')}>I am a customer</button>
            <button type="button" role="radio" aria-checked={isTailor} className={isTailor ? 'on' : ''} onClick={() => setRole('TAILOR')}>I am a tailor</button>
          </div>
        )}

        {mode === 'register' && (
          <label className="field">Full name
            <input className="input" value={f.name} onChange={set('name')} autoComplete="name" required />
          </label>
        )}
        {mode === 'register' && isTailor && (
          <label className="field">Shop name
            <input className="input" value={f.shopName} onChange={set('shopName')} required />
          </label>
        )}
        <label className="field">Email
          <input className="input" type="email" value={f.email} onChange={set('email')} autoComplete="email" required />
        </label>
        <label className="field">Password
          <input className="input" type="password" value={f.password} onChange={set('password')} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required />
        </label>
        {mode === 'register' && (
          <div className="two">
            <label className="field">Mobile number
              <input className="input" type="tel" value={f.mobile} onChange={set('mobile')} autoComplete="tel" required />
            </label>
            <label className="field">Area
              <input className="input" list="areas" value={f.city} onChange={set('city')} placeholder="For example, Kompally" required />
              <datalist id="areas">{AREAS.map((a) => <option key={a} value={a} />)}</datalist>
            </label>
          </div>
        )}
        {err && <p className="error" role="alert">{err}</p>}
        <button className="btn wide" disabled={busy}>{busy ? 'Please wait' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
      </form>
    </div>
  );
}
