import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { fmtShort } from '../util.js';

const EXAMPLES = [
  'I need a bridal blouse within 4 days, the best tailor near me',
  'Stitch a kurti in 3 days',
  'I want a sherwani in 2 weeks near Hitech City'
];

export function TailorCard({ t, onOpen }) {
  return (
    <article className="tcard">
      <div className="tcard-img" style={t.coverImage ? { backgroundImage: `url(${t.coverImage})` } : undefined} />
      <div className="tcard-body">
        <h4>{t.shopName}</h4>
        <p className="muted">{t.ownerName}, {t.address || t.area}</p>
        <p className="meta">
          <span>{t.rating > 0 ? t.rating.toFixed(1) + ' rating' : 'New on Techvastra'}</span>
          <span>{t.experienceYears} years</span>
          <span>{t.completedOrders} orders done</span>
        </p>
        {t.specialties && t.specialties.length > 0 && <p className="tags">{t.specialties.map((s) => <span key={s}>{s}</span>)}</p>}
        {t.matchNote
          ? <p className={'note' + (t.availableByDeadline === false ? ' off' : '')}>{t.matchNote}</p>
          : t.nextFreeDate && <p className="note">Next free date: {fmtShort(t.nextFreeDate)}</p>}
        <button className="btn small" onClick={onOpen}>View profile</button>
      </div>
    </article>
  );
}

export default function CustomerHome() {
  const { user } = useAuth();
  const nav = useNavigate();
  const first = user.name.split(' ')[0];
  const greeting = { from: 'bot', text: `Hello ${first}. Tell me what you need stitched and when you need it. For example: I need a bridal blouse within 4 days, the best tailor near me. You can also name an area, such as in Alwal.` };
  const [msgs, setMsgs] = useState([greeting]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const ctx = useRef({});
  const end = useRef(null);

  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [msgs, busy]);

  async function send(t) {
    const message = (t ?? text).trim();
    if (!message || busy) return;
    setText('');
    setMsgs((m) => [...m, { from: 'user', text: message }]);
    setBusy(true);
    try {
      const r = await api.post('/chat', { message, context: ctx.current });
      ctx.current = r.context || {};
      setMsgs((m) => [...m, { from: 'bot', text: r.reply, steps: r.steps, tailors: r.tailors, ctx: r.context }]);
    } catch (e) {
      setMsgs((m) => [...m, { from: 'bot', text: e.message }]);
    } finally {
      setBusy(false);
    }
  }

  function reset() { ctx.current = {}; setMsgs([greeting]); }

  return (
    <div className="chat">
      <div className="chat-head">
        <div>
          <h1>Find a tailor</h1>
          <p className="muted">Your area: {user.city}. The assistant searches tailors near you, checks their calendars and ranks them.</p>
        </div>
        <button className="btn small secondary" onClick={reset}>Start a new search</button>
      </div>

      <div className="msgs" aria-live="polite">
        {msgs.map((m, i) => (
          <div key={i} className={'msg ' + m.from}>
            <div className="bubble">
              <p>{m.text}</p>
              {m.steps && m.steps.length > 0 && (
                <ul className="steps" aria-label="What the assistant did">
                  {m.steps.map((s, k) => <li key={k}>{s}</li>)}
                </ul>
              )}
            </div>
            {m.tailors && m.tailors.length > 0 && (
              <div className="tcards">
                {m.tailors.map((t) => (
                  <TailorCard key={t.id} t={t} onOpen={() => nav('/customer/tailors/' + t.id, { state: { garment: m.ctx?.garment, days: m.ctx?.days } })} />
                ))}
              </div>
            )}
          </div>
        ))}
        {busy && <div className="msg bot"><div className="bubble typing">Searching tailors and checking calendars</div></div>}
        <div ref={end} />
      </div>

      {msgs.length === 1 && (
        <div className="chips">
          {EXAMPLES.map((e) => <button key={e} className="chip" onClick={() => send(e)}>{e}</button>)}
        </div>
      )}
      <form className="composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Describe what you need and by when" aria-label="Message" />
        <button className="btn" disabled={busy || !text.trim()}>Send</button>
      </form>
    </div>
  );
}
