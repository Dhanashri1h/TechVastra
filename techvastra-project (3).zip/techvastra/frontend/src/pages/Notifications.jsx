import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { fmtDateTime } from '../util.js';

export default function Notifications() {
  const [items, setItems] = useState(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    api.get('/notifications')
      .then(async (d) => {
        setItems(d.items);
        if (d.unread > 0) {
          await api.post('/notifications/read-all');
          window.dispatchEvent(new Event('tv-notif'));
        }
      })
      .catch((e) => setErr(e.message));
  }, []);

  if (!items) return <div className="page">{err ? <p className="error">{err}</p> : <p className="muted">Loading</p>}</div>;
  return (
    <div className="page narrow">
      <h1>Notifications</h1>
      {items.length === 0 && <div className="empty"><p>Nothing here yet. Updates about your orders will appear in this list.</p></div>}
      <ul className="nlist">
        {items.map((n) => (
          <li key={n.id} className={n.seen ? '' : 'unread'}>
            <p>{n.message}</p>
            <span className="muted">{fmtDateTime(n.createdAt)}</span>
            {n.orderId && <Link className="btn small secondary" to={'/orders/' + n.orderId}>Open order</Link>}
          </li>
        ))}
      </ul>
    </div>
  );
}
