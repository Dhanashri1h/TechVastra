import { useEffect, useRef, useState } from 'react';
import { api } from '../api.js';
import Calendar from '../components/Calendar.jsx';
import { AREAS } from '../areas.js';

export default function TailorProfileEdit() {
  const [t, setT] = useState(null);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [caption, setCaption] = useState('');
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);

  const adopt = (d) => {
    setT(d);
    setF({
      shopName: d.shopName || '', name: d.ownerName || '', mobile: d.mobile || '', city: d.city || '', address: d.address || '',
      bio: d.bio || '', experienceYears: d.experienceYears ?? 0, specialties: (d.specialties || []).join(', '),
      openTime: d.openTime || '10:00', closeTime: d.closeTime || '19:00', workingDays: d.workingDays || ''
    });
  };
  useEffect(() => { api.get('/tailor/profile').then(adopt).catch((e) => setErr(e.message)); }, []);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const flash = (m) => { setMsg(m); setTimeout(() => setMsg(''), 3000); };

  async function save(e) {
    e.preventDefault();
    setErr('');
    try {
      adopt(await api.put('/tailor/profile', f));
      const u = JSON.parse(localStorage.getItem('tv_user') || '{}');
      localStorage.setItem('tv_user', JSON.stringify({ ...u, name: f.name, city: f.city, mobile: f.mobile, shopName: f.shopName }));
      flash('Profile saved');
    } catch (ex) { setErr(ex.message); }
  }

  async function upload() {
    const file = fileRef.current?.files?.[0];
    if (!file) return setErr('Choose a photo first.');
    setErr('');
    setBusy(true);
    const form = new FormData();
    form.append('file', file);
    form.append('caption', caption);
    try {
      adopt(await api.upload('/tailor/gallery', form));
      setCaption('');
      fileRef.current.value = '';
      flash('Photo added to your gallery');
    } catch (ex) { setErr(ex.message); }
    finally { setBusy(false); }
  }

  async function removePhoto(id) {
    try { adopt(await api.del('/tailor/gallery/' + id)); flash('Photo removed'); }
    catch (ex) { setErr(ex.message); }
  }

  async function toggle(date) {
    try { adopt(await api.post('/tailor/dates/toggle', { date })); }
    catch (ex) { setErr(ex.message); }
  }

  if (!f) return <div className="page">{err ? <p className="error">{err}</p> : <p className="muted">Loading profile</p>}</div>;

  return (
    <div className="page">
      <h1>Profile and calendar</h1>
      <p className="muted">This is what customers see when they open your shop.</p>
      {msg && <p className="success" role="status">{msg}</p>}
      {err && <p className="error" role="alert">{err}</p>}

      <div className="cols">
        <div>
          <form className="card stack" onSubmit={save}>
            <h2>Shop details</h2>
            <div className="two">
              <label className="field">Shop name<input className="input" value={f.shopName} onChange={set('shopName')} /></label>
              <label className="field">Owner name<input className="input" value={f.name} onChange={set('name')} /></label>
            </div>
            <div className="two">
              <label className="field">Mobile number<input className="input" value={f.mobile} onChange={set('mobile')} /></label>
              <label className="field">Area<input className="input" list="areas" value={f.city} onChange={set('city')} /><datalist id="areas">{AREAS.map((a) => <option key={a} value={a} />)}</datalist></label>
            </div>
            <label className="field">Shop address<input className="input" value={f.address} onChange={set('address')} /></label>
            <label className="field">About your work<textarea className="input" rows="4" value={f.bio} onChange={set('bio')} /></label>
            <div className="two">
              <label className="field">Years of experience<input className="input" type="number" min="0" value={f.experienceYears} onChange={set('experienceYears')} /></label>
              <label className="field">Specialties, separated by commas<input className="input" value={f.specialties} onChange={set('specialties')} placeholder="Bridal blouse, Lehenga" /></label>
            </div>
            <h3>Order receiving hours</h3>
            <div className="three">
              <label className="field">Opens at<input className="input" type="time" value={f.openTime} onChange={set('openTime')} /></label>
              <label className="field">Closes at<input className="input" type="time" value={f.closeTime} onChange={set('closeTime')} /></label>
              <label className="field">Working days<input className="input" value={f.workingDays} onChange={set('workingDays')} /></label>
            </div>
            <button className="btn">Save profile</button>
          </form>

          <div className="card">
            <h2>Work gallery</h2>
            <div className="uploader">
              <input ref={fileRef} type="file" accept="image/*" aria-label="Choose a photo" />
              <input className="input" value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Caption, for example Bridal blouse" aria-label="Photo caption" />
              <button className="btn" onClick={upload} disabled={busy}>{busy ? 'Uploading' : 'Add photo'}</button>
            </div>
            {t.gallery.length === 0 ? <p className="muted">Add photos of your finished work so customers can trust your craft.</p> : (
              <div className="gallery">
                {t.gallery.map((g) => (
                  <figure key={g.id} className="gal static">
                    <img src={g.url} alt={g.caption} loading="lazy" />
                    <figcaption>{g.caption}</figcaption>
                    <button className="btn small secondary" onClick={() => removePhoto(g.id)}>Remove</button>
                  </figure>
                ))}
              </div>
            )}
          </div>
        </div>

        <aside>
          <div className="card">
            <h2>Free dates</h2>
            <p className="muted">Select a day to mark it free for new orders. Select it again to mark it unavailable. Changes save instantly.</p>
            <Calendar free={t.freeDates} mode="edit" onPick={toggle} />
          </div>
        </aside>
      </div>
    </div>
  );
}
