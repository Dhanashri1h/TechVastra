import { Link } from 'react-router-dom';
import { useAuth, homeFor } from '../AuthContext.jsx';

export default function Welcome() {
  const { user } = useAuth();
  return (
    <div className="welcome">
      <section className="welcome-main">
        <div className="brand big">Techvastra</div>
        <div>
          <h1>Welcome to Techvastra</h1>
          <p className="lead">Tell our assistant what you need stitched. It finds tailors near your area who are free before your deadline, and you follow every stage until the garment is ready.</p>
          {user && <Link className="btn light" to={homeFor(user)}>Continue as {user.name}</Link>}
        </div>
        <p className="fine">Customers and tailors sign in to separate workspaces.</p>
      </section>
      <section className="welcome-side" aria-label="Choose how to continue">
        <div className="ruler" aria-hidden="true" />
        <div className="choices">
          <h2>How would you like to continue?</h2>
          <div className="choice">
            <h3>I need something stitched</h3>
            <p>Chat with the assistant, compare nearby tailors and place an order.</p>
            <Link className="btn light" to="/auth?mode=register&role=CUSTOMER">Create a customer account</Link>
          </div>
          <div className="choice">
            <h3>I run a tailoring shop</h3>
            <p>Receive requests, update progress and manage your calendar and gallery.</p>
            <Link className="btn light" to="/auth?mode=register&role=TAILOR">Create a tailor account</Link>
          </div>
          <p className="signin">Already registered? <Link to="/auth?mode=login">Sign in</Link></p>
        </div>
      </section>
    </div>
  );
}
