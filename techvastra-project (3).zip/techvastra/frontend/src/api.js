const BASE = '/api';

async function req(path, { method = 'GET', body, form } = {}) {
  const headers = {};
  const token = localStorage.getItem('tv_token');
  if (token) headers.Authorization = 'Bearer ' + token;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  const res = await fetch(BASE + path, { method, headers, body: payload });
  if (!res.ok) {
    let msg = 'Something went wrong. Please try again.';
    try {
      const j = await res.json();
      msg = j.message || j.error || msg;
    } catch (e) { /* ignore */ }
    if (res.status === 401 && !path.startsWith('/auth/login')) {
      localStorage.removeItem('tv_token');
      localStorage.removeItem('tv_user');
      if (window.location.pathname !== '/auth') window.location.href = '/auth';
    }
    throw new Error(msg);
  }
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

export const api = {
  get: (p) => req(p),
  post: (p, body) => req(p, { method: 'POST', body: body ?? {} }),
  put: (p, body) => req(p, { method: 'PUT', body }),
  del: (p) => req(p, { method: 'DELETE' }),
  upload: (p, form) => req(p, { method: 'POST', form })
};
