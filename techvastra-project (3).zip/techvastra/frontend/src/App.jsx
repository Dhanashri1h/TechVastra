import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth, homeFor } from './AuthContext.jsx';
import Layout from './components/Layout.jsx';
import Welcome from './pages/Welcome.jsx';
import Auth from './pages/Auth.jsx';
import CustomerHome from './pages/CustomerHome.jsx';
import TailorView from './pages/TailorView.jsx';
import OrderForm from './pages/OrderForm.jsx';
import OrderList from './pages/OrderList.jsx';
import OrderDetail from './pages/OrderDetail.jsx';
import Notifications from './pages/Notifications.jsx';
import TailorProfileEdit from './pages/TailorProfileEdit.jsx';

function Only({ role, children }) {
  const { user } = useAuth();
  if (user && role && user.role !== role) return <Navigate to={homeFor(user)} replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Welcome />} />
      <Route path="/auth" element={<Auth />} />
      <Route element={<Layout />}>
        <Route path="/customer" element={<Only role="CUSTOMER"><CustomerHome /></Only>} />
        <Route path="/customer/tailors/:id" element={<Only role="CUSTOMER"><TailorView /></Only>} />
        <Route path="/customer/tailors/:id/order" element={<Only role="CUSTOMER"><OrderForm /></Only>} />
        <Route path="/orders" element={<Only role="CUSTOMER"><OrderList /></Only>} />
        <Route path="/tailor" element={<Only role="TAILOR"><OrderList /></Only>} />
        <Route path="/tailor/profile" element={<Only role="TAILOR"><TailorProfileEdit /></Only>} />
        <Route path="/orders/:id" element={<OrderDetail />} />
        <Route path="/notifications" element={<Notifications />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
