package com.techvastra.service;

import java.util.*;

/** Hyderabad areas with approximate coordinates, used to find tailors near a customer. */
public final class AreaData {
    private AreaData() {}

    public static final Map<String, double[]> AREAS = new LinkedHashMap<>();
    public static final Map<String, String> ALIASES = new LinkedHashMap<>();

    static {
        String[] names = {"Alwal", "Ameerpet", "Attapur", "Bachupally", "Balanagar", "Banjara Hills", "Begumpet", "Bowrampet", "Charminar", "Dilsukhnagar", "Dulapally", "Gachibowli", "Habsiguda", "Hitech City", "Jeedimetla", "Jubilee Hills", "Kompally", "Kondapur", "Kothapet", "KPHB Colony", "Kukatpally", "LB Nagar", "Madhapur", "Malkajgiri", "Manikonda", "Mehdipatnam", "Miyapur", "Moosapet", "Nampally", "Nizampet", "Quthbullapur", "Ram Nagar", "Sanath Nagar", "Secunderabad", "Shapur Nagar", "SR Nagar", "Suchitra", "Tarnaka", "Uppal", "Yousufguda"};
        double[][] pts = {
            {17.503, 78.518},
            {17.4375, 78.4483},
            {17.368, 78.426},
            {17.544, 78.362},
            {17.471, 78.438},
            {17.4156, 78.4347},
            {17.4447, 78.4664},
            {17.545, 78.385},
            {17.3616, 78.4747},
            {17.3688, 78.5247},
            {17.5391, 78.4488},
            {17.4401, 78.3489},
            {17.417, 78.54},
            {17.4435, 78.3772},
            {17.509, 78.456},
            {17.4326, 78.4071},
            {17.536, 78.487},
            {17.46, 78.364},
            {17.367, 78.54},
            {17.4933, 78.3914},
            {17.4948, 78.3996},
            {17.3457, 78.5522},
            {17.4486, 78.3908},
            {17.456, 78.528},
            {17.401, 78.387},
            {17.395, 78.439},
            {17.4969, 78.3548},
            {17.468, 78.426},
            {17.3912, 78.466},
            {17.52, 78.38},
            {17.512, 78.448},
            {17.413, 78.496},
            {17.456, 78.444},
            {17.4399, 78.4983},
            {17.517, 78.437},
            {17.443, 78.443},
            {17.5, 78.483},
            {17.428, 78.533},
            {17.4058, 78.5591},
            {17.435, 78.424}
        };
        for (int i = 0; i < names.length; i++) AREAS.put(names[i], pts[i]);
        String[][] al = {
            {"bworampet", "Bowrampet"},
            {"bowrampet", "Bowrampet"},
            {"komaplly", "Kompally"},
            {"kompalli", "Kompally"},
            {"hi-tech city", "Hitech City"},
            {"hitec city", "Hitech City"},
            {"hi tech city", "Hitech City"},
            {"hytech city", "Hitech City"},
            {"secundrabad", "Secunderabad"},
            {"secunderabad", "Secunderabad"},
            {"suchitra circle", "Suchitra"},
            {"shapur", "Shapur Nagar"},
            {"shapurnagar", "Shapur Nagar"},
            {"kphb", "KPHB Colony"},
            {"jeedimetla", "Jeedimetla"},
            {"jidimetla", "Jeedimetla"},
            {"dullapally", "Dulapally"},
            {"dulapally", "Dulapally"},
            {"ramnagar", "Ram Nagar"},
            {"lb nagar", "LB Nagar"}
        };
        for (String[] a : al) ALIASES.put(a[0], a[1]);
    }

    public static String norm(String s) {
        return s == null ? "" : s.toLowerCase().replaceAll("[^a-z]", "");
    }

    /** Returns the standard area name for what the person typed, or null if it is not a known area. */
    public static String canonical(String input) {
        String n = norm(input);
        if (n.isEmpty()) return null;
        for (String k : AREAS.keySet()) if (norm(k).equals(n)) return k;
        for (Map.Entry<String, String> e : ALIASES.entrySet()) if (norm(e.getKey()).equals(n)) return e.getValue();
        return null;
    }

    /** Finds an area mentioned inside a longer message. */
    public static String detect(String message) {
        String lower = message.toLowerCase();
        List<String> keys = new ArrayList<>(AREAS.keySet());
        keys.sort((a, b) -> b.length() - a.length());
        for (String k : keys) if (lower.matches(".*\\b" + k.toLowerCase().replace(" ", "[ -]?") + "\\b.*")) return k;
        for (Map.Entry<String, String> e : ALIASES.entrySet())
            if (lower.matches(".*\\b" + e.getKey().replace(" ", "[ -]?") + "\\b.*")) return e.getValue();
        return null;
    }

    public static double[] coords(String area) {
        String c = canonical(area);
        return c == null ? null : AREAS.get(c);
    }

    /** Distance in km between two areas, 0 for the same name, or null when it cannot be worked out. */
    public static Double distanceKm(String a, String b) {
        if (norm(a).equals(norm(b)) && !norm(a).isEmpty()) return 0.0;
        double[] x = coords(a), y = coords(b);
        if (x == null || y == null) return null;
        double r = 6371, dLa = Math.toRadians(y[0] - x[0]), dLo = Math.toRadians(y[1] - x[1]);
        double h = Math.sin(dLa / 2) * Math.sin(dLa / 2)
                + Math.cos(Math.toRadians(x[0])) * Math.cos(Math.toRadians(y[0])) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
        return Math.round(2 * r * Math.asin(Math.sqrt(h)) * 10) / 10.0;
    }
}
