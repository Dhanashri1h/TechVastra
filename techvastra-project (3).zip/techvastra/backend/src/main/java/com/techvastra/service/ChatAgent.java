package com.techvastra.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.techvastra.model.*;
import com.techvastra.repo.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * The Techvastra assistant. It works as a small agent: it reads the request, then calls tools
 * (city search, calendar check, ranking) and reports every step back to the customer.
 */
@Service
public class ChatAgent {
    private static final Pattern GARMENT_RX = Pattern.compile(
            "\\b(?:(bridal|designer|party|wedding|silk|cotton|embroidered|heavy|pattu|saree)\\s+)?"
                    + "(blouse|lehenga|saree fall|saree|salwar suit|salwar|churidar|kurti|kurta|sherwani|gown|dress|blazer|suit|shirt|trouser|pant|uniform|alteration|petticoat|pyjama|anarkali|skirt)s?\\b");
    private static final Pattern DAYS_RX = Pattern.compile(
            "\\b(\\d+|one|two|three|four|five|six|seven|eight|nine|ten)\\s*(day|days|week|weeks)\\b");
    private static final List<String> WORDS = List.of("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten");
    private static final double RADIUS_KM = 20;
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("EEE, d MMM");

    record Parsed(String garment, Integer days, String area) {}

    private final UserRepository users;
    private final TailorProfileRepository profiles;
    private final FreeDateRepository freeDates;
    private final TailorService tailors;
    private final ObjectMapper mapper = new ObjectMapper();

    @Value("${techvastra.ai.api-key:}") private String apiKey;
    @Value("${techvastra.ai.model:claude-sonnet-5-5}") private String model;

    public ChatAgent(UserRepository users, TailorProfileRepository profiles, FreeDateRepository freeDates, TailorService tailors) {
        this.users = users;
        this.profiles = profiles;
        this.freeDates = freeDates;
        this.tailors = tailors;
    }

    public Map<String, Object> handle(User customer, String message, Map<String, Object> ctx) {
        if (ctx == null) ctx = new HashMap<>();
        List<String> steps = new ArrayList<>();
        Map<Long, User> tailorUsers = users.findByRole("TAILOR").stream().collect(Collectors.toMap(u -> u.id, u -> u));

        Parsed p = null;
        if (apiKey != null && !apiKey.isBlank()) p = askModel(message);
        if (p == null) p = rules(message);

        String garment = p.garment() != null ? p.garment() : str(ctx.get("garment"));
        Integer days = p.days() != null ? p.days() : toInt(ctx.get("days"));
        String area = p.area() != null ? p.area() : (str(ctx.get("area")) != null ? str(ctx.get("area")) : customer.city);
        String canon = AreaData.canonical(area);
        if (canon != null) area = canon;

        Map<String, Object> out = new LinkedHashMap<>();
        Map<String, Object> newCtx = new LinkedHashMap<>();
        newCtx.put("garment", garment);
        newCtx.put("days", days);
        newCtx.put("area", area);
        out.put("context", newCtx);
        out.put("steps", steps);
        out.put("tailors", List.of());

        if (garment == null) {
            out.put("reply", "I can find a tailor for you. Tell me what you need stitched and when you need it. "
                    + "For example: I need a bridal blouse within 4 days. You can also name an area, such as in Kompally.");
            return out;
        }

        LocalDate today = LocalDate.now();
        LocalDate deadline = days != null ? today.plusDays(days) : null;
        steps.add("Understood the request: " + garment + (deadline != null ? ", needed by " + deadline.format(DAY) : ", no deadline given")
                + ", near " + area);

        // Tool 1: find tailors around the area
        List<Object[]> found = new ArrayList<>();   // {profile, distance or null}
        for (TailorProfile tp : profiles.findAll()) {
            User u = tailorUsers.get(tp.userId);
            if (u == null) continue;
            Double d = AreaData.distanceKm(area, u.city);
            if (d != null && d <= RADIUS_KM) found.add(new Object[]{tp, d});
        }
        boolean widened = false;
        if (found.isEmpty()) {
            widened = true;
            for (TailorProfile tp : profiles.findAll()) if (tailorUsers.containsKey(tp.userId)) found.add(new Object[]{tp, AreaData.distanceKm(area, tailorUsers.get(tp.userId).city)});
        }
        if (found.isEmpty()) {
            out.put("reply", "No tailors have registered yet. Please check again soon.");
            return out;
        }
        steps.add(widened ? "No tailors found within " + (int) RADIUS_KM + " km of " + area + ", so I searched every registered tailor"
                : "Searched tailors within " + (int) RADIUS_KM + " km of " + area + ": " + found.size() + " found");

        // Tool 2: check calendars, Tool 3: rank
        String core = garment.substring(garment.lastIndexOf(' ') + 1);
        List<Object[]> scored = new ArrayList<>();
        int availableCount = 0;
        for (Object[] f : found) {
            TailorProfile tp = (TailorProfile) f[0];
            Double dist = (Double) f[1];
            List<FreeDate> fd = freeDates.findByTailorIdAndFreeDateGreaterThanEqualOrderByFreeDate(tp.userId, today);
            LocalDate firstInWindow = null;
            if (deadline != null) {
                for (FreeDate x : fd) if (!x.freeDate.isAfter(deadline)) { firstInWindow = x.freeDate; break; }
            }
            String spec = tp.specialties == null ? "" : tp.specialties.toLowerCase();
            boolean exact = spec.contains(garment);
            boolean related = exact || spec.contains(core);
            double score = tp.rating * 2 + Math.min(tp.experienceYears, 25) * 0.08
                    + (related ? 3 : 0) + (exact ? 1 : 0) + (firstInWindow != null ? 4 : 0) - (dist != null ? dist * 0.15 : 0);
            if (firstInWindow != null) availableCount++;

            Map<String, Object> card = tailors.card(tp);
            List<String> notes = new ArrayList<>();
            if (dist != null) notes.add(dist < 1 ? "In your area" : String.format("%.1f km away", dist));
            if (related) notes.add("Specialises in " + core + " work");
            if (deadline != null) notes.add(firstInWindow != null ? "Free on " + firstInWindow.format(DAY) : "No free date before your deadline");
            card.put("matchNote", String.join(". ", notes));
            card.put("distanceKm", dist);
            card.put("availableByDeadline", deadline == null ? null : firstInWindow != null);
            scored.add(new Object[]{score, card});
        }
        if (deadline != null) steps.add("Checked each tailor's calendar before " + deadline.format(DAY) + ": " + availableCount + " available");
        steps.add("Ranked by distance, availability, specialty match, rating and experience");

        scored.sort((a, b) -> Double.compare((double) b[0], (double) a[0]));
        out.put("tailors", scored.stream().limit(6).map(x -> x[1]).collect(Collectors.toList()));

        StringBuilder r = new StringBuilder("I found " + found.size() + " tailor" + (found.size() == 1 ? "" : "s")
                + (widened ? " in Hyderabad" : " near " + area) + " for your " + garment);
        if (deadline != null) {
            r.append(", needed by ").append(deadline.format(DAY)).append(". ")
                    .append(availableCount == 0 ? "None of them has a free date before your deadline, so check their calendars or try a later date. "
                            : availableCount + " of them " + (availableCount == 1 ? "has" : "have") + " a free date before your deadline. ");
        } else {
            r.append(". Tell me by when you need it and I will check their calendars. ");
        }
        r.append("The best matches are listed first. Open a profile to see their work, then send a request.");
        out.put("reply", r.toString());
        return out;
    }

    // ---------- understanding the request ----------

    private Parsed rules(String message) {
        String lower = message.toLowerCase();
        Matcher gm = GARMENT_RX.matcher(lower);
        String garment = gm.find() ? gm.group().trim() : null;
        Integer days = null;
        Matcher dm = DAYS_RX.matcher(lower);
        if (dm.find()) {
            int n = dm.group(1).matches("\\d+") ? Integer.parseInt(dm.group(1)) : WORDS.indexOf(dm.group(1));
            days = dm.group(2).startsWith("week") ? n * 7 : n;
        } else if (lower.contains("tomorrow")) days = 1;
        else if (lower.contains("today")) days = 0;
        else if (lower.matches(".*\\b(next week|a week|one week)\\b.*")) days = 7;
        return new Parsed(garment, days, AreaData.detect(message));
    }

    private Parsed askModel(String message) {
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model", model);
            body.put("max_tokens", 200);
            body.put("system", "You extract tailoring request details from a customer message. Known areas of Hyderabad: " + AreaData.AREAS.keySet()
                    + ". Reply with JSON only, no markdown: {\"garment\": string or null, \"days\": integer or null, \"area\": string or null}. "
                    + "days is the number of days from today by which the garment is needed. area must be one of the known areas or null.");
            body.put("messages", List.of(Map.of("role", "user", "content", message)));
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.anthropic.com/v1/messages"))
                    .header("content-type", "application/json").header("x-api-key", apiKey)
                    .header("anthropic-version", "2023-06-01").timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body))).build();
            HttpResponse<String> res = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) return null;
            String text = mapper.readTree(res.body()).path("content").path(0).path("text").asText("")
                    .replace("```json", "").replace("```", "").trim();
            JsonNode n = mapper.readTree(text);
            String g = n.path("garment").isNull() || n.path("garment").isMissingNode() ? null : n.path("garment").asText().toLowerCase();
            Integer d = n.path("days").isNumber() ? n.path("days").asInt() : null;
            String ar = n.path("area").isNull() ? null : AreaData.canonical(n.path("area").asText(null));
            return new Parsed(g, d, ar);
        } catch (Exception e) {
            return null;
        }
    }

    private static String str(Object o) {
        return o == null || o.toString().isBlank() ? null : o.toString();
    }

    private static Integer toInt(Object o) {
        return o instanceof Number ? ((Number) o).intValue() : null;
    }
}
