package com.techvastra.repo;

import com.techvastra.model.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FreeDateRepository extends JpaRepository<FreeDate, Long> {
    List<FreeDate> findByTailorIdAndFreeDateGreaterThanEqualOrderByFreeDate(Long tailorId, LocalDate from);
    Optional<FreeDate> findByTailorIdAndFreeDate(Long tailorId, LocalDate freeDate);
}
