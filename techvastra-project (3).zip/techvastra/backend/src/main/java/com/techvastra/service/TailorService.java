package com.techvastra.service;

import com.techvastra.model.*;
import com.techvastra.repo.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TailorService {
    private final UserRepository users;
    private final TailorProfileRepository profiles;
    private final GalleryRepository gallery;
    private final FreeDateRepository freeDates;
    private final OrderRepository orders;

    public TailorService(UserRepository users, TailorProfileRepository profiles, GalleryRepository gallery,
                         FreeDateRepository freeDates, OrderRepository orders) {
        this.users = users;
        this.profiles = profiles;
        this.gallery = gallery;
        this.freeDates = freeDates;
        this.orders = orders;
    }

    public static List<String> split(String s) {
        if (s == null || s.isBlank()) return List.of();
        return Arrays.stream(s.split(",")).map(String::trim).filter(x -> !x.isEmpty()).collect(Collectors.toList());
    }

    public Map<String, Object> card(TailorProfile p) {
        User u = users.findById(p.userId).orElseThrow();
        List<GalleryImage> g = gallery.findByTailorIdOrderByIdAsc(p.userId);
        List<FreeDate> fd = freeDates.findByTailorIdAndFreeDateGreaterThanEqualOrderByFreeDate(p.userId, LocalDate.now());
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", u.id);
        m.put("shopName", p.shopName);
        m.put("ownerName", u.name);
        m.put("city", u.city);
        m.put("area", u.city);
        m.put("address", p.address);
        m.put("experienceYears", p.experienceYears);
        m.put("rating", p.rating);
        m.put("completedOrders", p.completedOrders);
        m.put("specialties", split(p.specialties));
        m.put("coverImage", g.isEmpty() ? null : g.get(0).url);
        m.put("nextFreeDate", fd.isEmpty() ? null : fd.get(0).freeDate.toString());
        return m;
    }

    public Map<String, Object> detail(Long tailorUserId, boolean withContact) {
        TailorProfile p = profiles.findByUserId(tailorUserId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tailor not found"));
        Map<String, Object> m = card(p);
        m.put("bio", p.bio);
        m.put("openTime", p.openTime);
        m.put("closeTime", p.closeTime);
        m.put("workingDays", p.workingDays);
        m.put("activeOrders", orders.countByTailorIdAndStatus(tailorUserId, "ACCEPTED"));
        List<Map<String, Object>> g = new ArrayList<>();
        for (GalleryImage gi : gallery.findByTailorIdOrderByIdAsc(tailorUserId)) {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("id", gi.id);
            x.put("url", gi.url);
            x.put("caption", gi.caption);
            g.add(x);
        }
        m.put("gallery", g);
        m.put("freeDates", freeDates.findByTailorIdAndFreeDateGreaterThanEqualOrderByFreeDate(tailorUserId, LocalDate.now())
                .stream().map(f -> f.freeDate.toString()).collect(Collectors.toList()));
        if (withContact) {
            User u = users.findById(tailorUserId).orElseThrow();
            m.put("mobile", u.mobile);
            m.put("email", u.email);
        }
        return m;
    }
}
