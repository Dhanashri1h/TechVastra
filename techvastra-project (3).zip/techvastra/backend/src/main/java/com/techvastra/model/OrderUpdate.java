package com.techvastra.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "order_updates")
public class OrderUpdate {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public Long orderId;
    public String stage;
    @Column(length = 1000) public String note;
    public LocalDateTime createdAt;
}
