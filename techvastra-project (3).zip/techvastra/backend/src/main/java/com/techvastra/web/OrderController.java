package com.techvastra.web;

import com.techvastra.config.Auth;
import com.techvastra.model.*;
import com.techvastra.repo.*;
import com.techvastra.service.FileService;
import com.techvastra.service.Notifier;
import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    public static final List<String> STAGES = List.of("Order accepted", "Measurements taken", "Fabric received",
            "Cutting done", "Stitching in progress", "Threading and finishing", "Ready for pickup");

    private final OrderRepository orders;
    private final OrderUpdateRepository updates;
    private final UserRepository users;
    private final TailorProfileRepository profiles;
    private final Notifier notifier;
    private final FileService files;

    public OrderController(OrderRepository orders, OrderUpdateRepository updates, UserRepository users,
                           TailorProfileRepository profiles, Notifier notifier, FileService files) {
        this.orders = orders;
        this.updates = updates;
        this.users = users;
        this.profiles = profiles;
        this.notifier = notifier;
        this.files = files;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> create(HttpServletRequest req, @RequestParam Long tailorId, @RequestParam String garment,
                                      @RequestParam String dueDate, @RequestParam(required = false) String notes,
                                      @RequestParam(required = false) String fabricDetails,
                                      @RequestParam(required = false) String measurements,
                                      @RequestParam(required = false) MultipartFile audio) {
        User c = Auth.require(req, "CUSTOMER");
        User t = users.findById(tailorId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tailor not found"));
        if (!"TAILOR".equals(t.role)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not a tailor account");
        if (garment.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tell the tailor what you need stitched");
        LocalDate due;
        try { due = LocalDate.parse(dueDate); }
        catch (Exception e) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose the date you need it by"); }
        if (due.isBefore(LocalDate.now())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "The date cannot be in the past");

        OrderRequest o = new OrderRequest();
        o.customerId = c.id;
        o.tailorId = t.id;
        o.garment = garment.trim();
        o.notes = notes == null ? "" : notes.trim();
        o.fabricDetails = fabricDetails == null ? "" : fabricDetails.trim();
        o.measurements = measurements == null ? "" : measurements.trim();
        o.dueDate = due;
        if (audio != null && !audio.isEmpty()) o.audioUrl = files.save(audio, "voice");
        o.status = "REQUESTED";
        o.stage = "Request sent";
        o.createdAt = LocalDateTime.now();
        orders.save(o);
        log(o, "Request sent", "Order request sent to " + profiles.findByUserId(t.id).map(p -> p.shopName).orElse("the tailor"));
        notifier.send(t.id, "New request from " + c.name + ": " + o.garment + ", needed by " + o.dueDate, o.id);
        return view(o, c);
    }

    @GetMapping
    public List<Map<String, Object>> list(HttpServletRequest req) {
        User u = Auth.require(req, null);
        List<OrderRequest> list = "TAILOR".equals(u.role)
                ? orders.findByTailorIdOrderByCreatedAtDesc(u.id) : orders.findByCustomerIdOrderByCreatedAtDesc(u.id);
        List<Map<String, Object>> out = new ArrayList<>();
        for (OrderRequest o : list) out.add(view(o, u));
        return out;
    }

    @GetMapping("/{id}")
    public Map<String, Object> one(HttpServletRequest req, @PathVariable Long id) {
        User u = Auth.require(req, null);
        OrderRequest o = find(id, u);
        Map<String, Object> m = view(o, u);
        List<Map<String, Object>> tl = new ArrayList<>();
        for (OrderUpdate x : updates.findByOrderIdOrderByCreatedAtAscIdAsc(o.id)) {
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("stage", x.stage);
            e.put("note", x.note);
            e.put("createdAt", x.createdAt.toString());
            tl.add(e);
        }
        m.put("updates", tl);
        m.put("stages", STAGES);
        return m;
    }

    @PostMapping("/{id}/accept")
    public Map<String, Object> accept(HttpServletRequest req, @PathVariable Long id) {
        User t = Auth.require(req, "TAILOR");
        OrderRequest o = find(id, t);
        if (!"REQUESTED".equals(o.status)) throw new ResponseStatusException(HttpStatus.CONFLICT, "This request was already answered");
        o.status = "ACCEPTED";
        o.stage = STAGES.get(0);
        orders.save(o);
        log(o, o.stage, "The tailor accepted your request");
        notifier.send(o.customerId, shop(t) + " accepted your request for " + o.garment + ". You can now see the contact number.", o.id);
        return view(o, t);
    }

    @PostMapping("/{id}/reject")
    public Map<String, Object> reject(HttpServletRequest req, @PathVariable Long id, @RequestBody(required = false) Map<String, String> b) {
        User t = Auth.require(req, "TAILOR");
        OrderRequest o = find(id, t);
        if (!"REQUESTED".equals(o.status)) throw new ResponseStatusException(HttpStatus.CONFLICT, "This request was already answered");
        o.status = "REJECTED";
        o.stage = "Declined";
        orders.save(o);
        log(o, "Declined", b == null ? "" : b.getOrDefault("note", ""));
        notifier.send(o.customerId, shop(t) + " could not take your request for " + o.garment + ". Try another tailor.", o.id);
        return view(o, t);
    }

    @PostMapping("/{id}/status")
    public Map<String, Object> status(HttpServletRequest req, @PathVariable Long id, @RequestBody Map<String, String> b) {
        User t = Auth.require(req, "TAILOR");
        OrderRequest o = find(id, t);
        if (!"ACCEPTED".equals(o.status)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Only orders in progress can be updated");
        String stage = b.get("stage");
        if (stage == null || !STAGES.contains(stage)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose a valid stage");
        o.stage = stage;
        orders.save(o);
        String note = b.getOrDefault("note", "").trim();
        log(o, stage, note);
        notifier.send(o.customerId, "Update on your " + o.garment + ": " + stage.toLowerCase() + ".", o.id);
        return view(o, t);
    }

    @PostMapping("/{id}/complete")
    public Map<String, Object> complete(HttpServletRequest req, @PathVariable Long id) {
        User t = Auth.require(req, "TAILOR");
        OrderRequest o = find(id, t);
        if (!"ACCEPTED".equals(o.status)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Only orders in progress can be ended");
        o.status = "COMPLETED";
        o.stage = "Completed";
        orders.save(o);
        profiles.findByUserId(t.id).ifPresent(p -> { p.completedOrders++; profiles.save(p); });
        log(o, "Completed", "Stitching is finished and the order is closed");
        notifier.send(o.customerId, "Your " + o.garment + " is stitched and the order is complete.", o.id);
        return view(o, t);
    }

    // ----- helpers -----

    private OrderRequest find(Long id, User u) {
        OrderRequest o = orders.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));
        if (!u.id.equals(o.customerId) && !u.id.equals(o.tailorId))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "This order belongs to someone else");
        return o;
    }

    private void log(OrderRequest o, String stage, String note) {
        OrderUpdate x = new OrderUpdate();
        x.orderId = o.id;
        x.stage = stage;
        x.note = note;
        x.createdAt = LocalDateTime.now();
        updates.save(x);
    }

    private String shop(User t) {
        return profiles.findByUserId(t.id).map(p -> p.shopName).orElse(t.name);
    }

    private Map<String, Object> view(OrderRequest o, User viewer) {
        User c = users.findById(o.customerId).orElseThrow();
        User t = users.findById(o.tailorId).orElseThrow();
        TailorProfile p = profiles.findByUserId(t.id).orElse(null);
        boolean visible = "ACCEPTED".equals(o.status) || "COMPLETED".equals(o.status);
        int progress;
        if ("COMPLETED".equals(o.status)) progress = 100;
        else if ("ACCEPTED".equals(o.status)) progress = (STAGES.indexOf(o.stage) + 1) * 100 / (STAGES.size() + 1);
        else progress = 0;
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", o.id);
        m.put("garment", o.garment);
        m.put("notes", o.notes);
        m.put("fabricDetails", o.fabricDetails);
        m.put("measurements", o.measurements);
        m.put("dueDate", o.dueDate.toString());
        m.put("audioUrl", o.audioUrl);
        m.put("status", o.status);
        m.put("stage", o.stage);
        m.put("progress", progress);
        m.put("createdAt", o.createdAt.toString());
        m.put("customerName", c.name);
        m.put("customerCity", c.city);
        m.put("tailorId", t.id);
        m.put("shopName", p == null ? t.name : p.shopName);
        m.put("tailorName", t.name);
        m.put("contactVisible", visible);
        if (visible) {
            m.put("customerMobile", c.mobile);
            m.put("tailorMobile", t.mobile);
            m.put("tailorAddress", p == null ? "" : p.address);
        }
        return m;
    }
}
