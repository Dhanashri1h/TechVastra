package com.techvastra.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    private final AuthInterceptor auth;
    @Value("${techvastra.upload-dir:uploads}") private String uploadDir;

    public WebConfig(AuthInterceptor auth) {
        this.auth = auth;
    }

    @Override
    public void addInterceptors(InterceptorRegistry r) {
        r.addInterceptor(auth).addPathPatterns("/api/**")
                .excludePathPatterns("/api/auth/login", "/api/auth/register", "/api/placeholder/**");
    }

    @Override
    public void addCorsMappings(CorsRegistry r) {
        r.addMapping("/**").allowedOriginPatterns("*").allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS").allowedHeaders("*");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry r) {
        try {
            Path dir = Paths.get(uploadDir).toAbsolutePath();
            Files.createDirectories(dir);
            r.addResourceHandler("/uploads/**").addResourceLocations(dir.toUri().toString());
        } catch (IOException e) {
            throw new IllegalStateException("Cannot create upload directory", e);
        }
    }
}
