package com.techvastra.web;

import com.techvastra.config.Auth;
import com.techvastra.model.Notification;
import com.techvastra.model.User;
import com.techvastra.repo.NotificationRepository;
import jakarta.servlet.http.HttpServletRequest;
import java.util.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationRepository repo;

    public NotificationController(NotificationRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public Map<String, Object> list(HttpServletRequest req) {
        User u = Auth.require(req, null);
        List<Map<String, Object>> items = new ArrayList<>();
        int unread = 0;
        for (Notification n : repo.findByUserIdOrderByCreatedAtDescIdDesc(u.id)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", n.id);
            m.put("message", n.message);
            m.put("orderId", n.orderId);
            m.put("seen", n.seen);
            m.put("createdAt", n.createdAt.toString());
            items.add(m);
            if (!n.seen) unread++;
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("items", items);
        out.put("unread", unread);
        return out;
    }

    @PostMapping("/read-all")
    public Map<String, Object> readAll(HttpServletRequest req) {
        User u = Auth.require(req, null);
        List<Notification> list = repo.findByUserIdAndSeenFalse(u.id);
        list.forEach(n -> n.seen = true);
        repo.saveAll(list);
        return Map.of("ok", true);
    }
}
