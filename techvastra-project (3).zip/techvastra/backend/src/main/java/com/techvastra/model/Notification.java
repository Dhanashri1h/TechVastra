package com.techvastra.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public Long userId;
    @Column(length = 600) public String message;
    public Long orderId;
    public boolean seen;
    public LocalDateTime createdAt;
}
