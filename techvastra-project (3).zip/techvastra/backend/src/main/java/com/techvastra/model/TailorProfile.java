package com.techvastra.model;

import jakarta.persistence.*;

@Entity
@Table(name = "tailor_profiles")
public class TailorProfile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(unique = true) public Long userId;
    public String shopName;
    public String address;
    @Column(length = 1500) public String bio;
    public int experienceYears;
    @Column(length = 500) public String specialties;   // comma separated
    public String openTime;
    public String closeTime;
    public String workingDays;
    public double rating;
    public int completedOrders;
}
