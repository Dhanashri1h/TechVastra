package com.techvastra.repo;

import com.techvastra.model.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<OrderRequest, Long> {
    List<OrderRequest> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
    List<OrderRequest> findByTailorIdOrderByCreatedAtDesc(Long tailorId);
    long countByTailorIdAndStatus(Long tailorId, String status);
}
