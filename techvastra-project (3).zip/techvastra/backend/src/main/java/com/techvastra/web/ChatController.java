package com.techvastra.web;

import com.techvastra.config.Auth;
import com.techvastra.model.User;
import com.techvastra.service.ChatAgent;
import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/chat")
public class ChatController {
    private final ChatAgent agent;

    public ChatController(ChatAgent agent) {
        this.agent = agent;
    }

    @PostMapping
    @SuppressWarnings("unchecked")
    public Map<String, Object> chat(HttpServletRequest req, @RequestBody Map<String, Object> b) {
        User u = Auth.require(req, "CUSTOMER");
        Object msg = b.get("message");
        if (msg == null || msg.toString().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Type a message first");
        Map<String, Object> ctx = b.get("context") instanceof Map ? new HashMap<>((Map<String, Object>) b.get("context")) : new HashMap<>();
        return agent.handle(u, msg.toString().trim(), ctx);
    }
}
