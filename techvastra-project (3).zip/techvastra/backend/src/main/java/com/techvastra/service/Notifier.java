package com.techvastra.service;

import com.techvastra.model.Notification;
import com.techvastra.repo.NotificationRepository;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;

@Service
public class Notifier {
    private final NotificationRepository repo;

    public Notifier(NotificationRepository repo) {
        this.repo = repo;
    }

    public void send(Long userId, String message, Long orderId) {
        Notification n = new Notification();
        n.userId = userId;
        n.message = message;
        n.orderId = orderId;
        n.seen = false;
        n.createdAt = LocalDateTime.now();
        repo.save(n);
    }
}
