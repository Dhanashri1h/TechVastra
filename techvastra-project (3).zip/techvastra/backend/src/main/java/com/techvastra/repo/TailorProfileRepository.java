package com.techvastra.repo;

import com.techvastra.model.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TailorProfileRepository extends JpaRepository<TailorProfile, Long> {
    Optional<TailorProfile> findByUserId(Long userId);
}
