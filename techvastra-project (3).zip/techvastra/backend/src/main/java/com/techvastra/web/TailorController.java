package com.techvastra.web;

import com.techvastra.config.Auth;
import com.techvastra.model.*;
import com.techvastra.repo.*;
import com.techvastra.service.FileService;
import com.techvastra.service.TailorService;
import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class TailorController {
    private final UserRepository users;
    private final TailorProfileRepository profiles;
    private final GalleryRepository gallery;
    private final FreeDateRepository freeDates;
    private final TailorService service;
    private final FileService files;

    public TailorController(UserRepository users, TailorProfileRepository profiles, GalleryRepository gallery,
                            FreeDateRepository freeDates, TailorService service, FileService files) {
        this.users = users;
        this.profiles = profiles;
        this.gallery = gallery;
        this.freeDates = freeDates;
        this.service = service;
        this.files = files;
    }

    // ----- customer side -----

    @GetMapping("/tailors")
    public List<Map<String, Object>> list(HttpServletRequest req, @RequestParam(required = false) String city) {
        Auth.require(req, null);
        List<Map<String, Object>> out = new ArrayList<>();
        for (TailorProfile p : profiles.findAll()) {
            User u = users.findById(p.userId).orElse(null);
            if (u == null) continue;
            if (city != null && !city.isBlank() && !city.trim().equalsIgnoreCase(u.city)) continue;
            out.add(service.card(p));
        }
        return out;
    }

    @GetMapping("/tailors/{id}")
    public Map<String, Object> one(HttpServletRequest req, @PathVariable Long id) {
        Auth.require(req, null);
        return service.detail(id, false);
    }

    // ----- tailor side -----

    @GetMapping("/tailor/profile")
    public Map<String, Object> mine(HttpServletRequest req) {
        User u = Auth.require(req, "TAILOR");
        return service.detail(u.id, true);
    }

    @PutMapping("/tailor/profile")
    public Map<String, Object> update(HttpServletRequest req, @RequestBody Map<String, Object> b) {
        User u = Auth.require(req, "TAILOR");
        TailorProfile p = profiles.findByUserId(u.id).orElseThrow();
        if (has(b, "name")) u.name = s(b, "name");
        if (has(b, "mobile")) u.mobile = s(b, "mobile");
        if (has(b, "city")) u.city = s(b, "city");
        users.save(u);
        if (has(b, "shopName")) p.shopName = s(b, "shopName");
        if (b.containsKey("address")) p.address = s(b, "address");
        if (b.containsKey("bio")) p.bio = s(b, "bio");
        if (b.containsKey("specialties")) p.specialties = s(b, "specialties");
        if (has(b, "openTime")) p.openTime = s(b, "openTime");
        if (has(b, "closeTime")) p.closeTime = s(b, "closeTime");
        if (b.containsKey("workingDays")) p.workingDays = s(b, "workingDays");
        if (has(b, "experienceYears")) {
            try { p.experienceYears = Math.max(0, Integer.parseInt(s(b, "experienceYears"))); }
            catch (NumberFormatException e) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Experience must be a number of years"); }
        }
        profiles.save(p);
        return service.detail(u.id, true);
    }

    @PostMapping(value = "/tailor/gallery", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> addPhoto(HttpServletRequest req, @RequestParam MultipartFile file,
                                        @RequestParam(required = false) String caption) {
        User u = Auth.require(req, "TAILOR");
        String type = file.getContentType();
        if (type == null || !type.startsWith("image/"))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please choose an image file");
        GalleryImage g = new GalleryImage();
        g.tailorId = u.id;
        g.url = files.save(file, "work");
        g.caption = caption == null || caption.isBlank() ? "Recent work" : caption.trim();
        gallery.save(g);
        return service.detail(u.id, true);
    }

    @DeleteMapping("/tailor/gallery/{id}")
    public Map<String, Object> removePhoto(HttpServletRequest req, @PathVariable Long id) {
        User u = Auth.require(req, "TAILOR");
        gallery.findById(id).ifPresent(g -> {
            if (g.tailorId.equals(u.id)) gallery.delete(g);
        });
        return service.detail(u.id, true);
    }

    @PostMapping("/tailor/dates/toggle")
    public Map<String, Object> toggle(HttpServletRequest req, @RequestBody Map<String, String> b) {
        User u = Auth.require(req, "TAILOR");
        LocalDate d;
        try { d = LocalDate.parse(b.get("date")); }
        catch (Exception e) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid date"); }
        if (d.isBefore(LocalDate.now())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Past dates cannot be changed");
        Optional<FreeDate> existing = freeDates.findByTailorIdAndFreeDate(u.id, d);
        if (existing.isPresent()) freeDates.delete(existing.get());
        else {
            FreeDate f = new FreeDate();
            f.tailorId = u.id;
            f.freeDate = d;
            freeDates.save(f);
        }
        return service.detail(u.id, true);
    }

    private static boolean has(Map<String, Object> b, String k) {
        return b.get(k) != null && !b.get(k).toString().isBlank();
    }

    private static String s(Map<String, Object> b, String k) {
        return b.get(k) == null ? "" : b.get(k).toString().trim();
    }
}
