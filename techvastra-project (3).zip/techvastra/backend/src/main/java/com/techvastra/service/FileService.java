package com.techvastra.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@Service
public class FileService {
    @Value("${techvastra.upload-dir:uploads}") private String uploadDir;

    /** Saves an uploaded file and returns its public URL path. */
    public String save(MultipartFile f, String prefix) {
        try {
            Path dir = Paths.get(uploadDir).toAbsolutePath();
            Files.createDirectories(dir);
            String ext = "";
            String name = f.getOriginalFilename();
            if (name != null && name.contains(".")) {
                ext = name.substring(name.lastIndexOf('.') + 1).replaceAll("[^A-Za-z0-9]", "");
                if (ext.length() > 5) ext = ext.substring(0, 5);
            }
            String file = prefix + "-" + UUID.randomUUID() + (ext.isEmpty() ? "" : "." + ext.toLowerCase());
            f.transferTo(dir.resolve(file));
            return "/uploads/" + file;
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Could not save the file");
        }
    }
}
