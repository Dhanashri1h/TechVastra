package com.techvastra.model;

import jakarta.persistence.*;

@Entity
@Table(name = "gallery_images")
public class GalleryImage {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public Long tailorId;
    @Column(length = 500) public String url;
    public String caption;
}
