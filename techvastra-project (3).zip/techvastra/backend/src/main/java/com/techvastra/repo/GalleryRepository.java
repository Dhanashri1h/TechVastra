package com.techvastra.repo;

import com.techvastra.model.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GalleryRepository extends JpaRepository<GalleryImage, Long> {
    List<GalleryImage> findByTailorIdOrderByIdAsc(Long tailorId);
}
