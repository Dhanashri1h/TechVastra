package com.techvastra.config;

import com.techvastra.model.*;
import com.techvastra.repo.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/** Loads demo customers, tailors, galleries, calendars and orders on the first run. */
@Component
public class DataSeeder implements CommandLineRunner {
    private final UserRepository users;
    private final TailorProfileRepository profiles;
    private final GalleryRepository gallery;
    private final FreeDateRepository freeDates;
    private final OrderRepository orders;
    private final OrderUpdateRepository updates;
    private final NotificationRepository notifications;
    @Value("${techvastra.reseed:false}") private boolean reseed;

    public DataSeeder(UserRepository users, TailorProfileRepository profiles, GalleryRepository gallery,
                      FreeDateRepository freeDates, OrderRepository orders, OrderUpdateRepository updates,
                      NotificationRepository notifications) {
        this.users = users;
        this.profiles = profiles;
        this.gallery = gallery;
        this.freeDates = freeDates;
        this.orders = orders;
        this.updates = updates;
        this.notifications = notifications;
    }

    private User user(String role, String name, String email, String mobile, String city, String hash) {
        User u = new User();
        u.role = role;
        u.name = name;
        u.email = email;
        u.mobile = mobile;
        u.city = city;
        u.passwordHash = hash;
        u.token = null;
        return users.save(u);
    }

    /** Picks which stored illustration matches a specialty. */
    private static String styleOf(String spec) {
        String x = spec.toLowerCase();
        if (x.contains("blouse")) return "blouse";
        if (x.contains("lehenga")) return "lehenga";
        if (x.contains("saree")) return "saree";
        if (x.contains("sherwani")) return "sherwani";
        if (x.contains("suit") && !x.contains("salwar") || x.contains("blazer")) return "blazer";
        if (x.contains("salwar") || x.contains("kurti")) return "kurti";
        if (x.contains("kurta") || x.contains("pyjama")) return "kurta";
        if (x.contains("shirt") || x.contains("uniform")) return "shirt";
        if (x.contains("trouser")) return "trouser";
        if (x.contains("gown") || x.contains("designer")) return "gown";
        if (x.contains("alteration")) return "alteration";
        return "blouse";
    }

    @Override
    public void run(String... args) {
        if (reseed) {
            notifications.deleteAll();
            updates.deleteAll();
            orders.deleteAll();
            freeDates.deleteAll();
            gallery.deleteAll();
            profiles.deleteAll();
            users.deleteAll();
        } else if (users.count() > 0) {
            return;
        }
        String hash = new BCryptPasswordEncoder().encode("password123");

        User customer = user("CUSTOMER", "Ananya Reddy", "customer@techvastra.com", "9876500001", "Kompally", hash);
        user("CUSTOMER", "Rahul Verma", "customer2@techvastra.com", "9876500002", "Alwal", hash);

        // name, email, mobile, city, shop, address, years, rating, completed, specialties, bio, open, close, days
        String[][] t = {
            {"Lakshmi Meera", "tailor1@techvastra.com", "9876500011", "Kompally", "Meera Boutique Studio", "Plot 14, Main Road, Kompally", "12", "4.9", "412",
                "Bridal blouse,Lehenga,Saree fall,Designer wear", "Twelve years of bridal and festive blouses with hand embroidery, padded cups and perfect fitting. Every piece gets two trial fittings.", "10:00", "19:00", "Monday to Saturday"},
            {"Imran Sheikh", "tailor2@techvastra.com", "9876500012", "Hitech City", "Royal Stitch House", "Road 2, Near Cyber Towers, Hitech City", "15", "4.8", "530",
                "Sherwani,Suits,Blazer,Shirt", "Gents tailoring for weddings and the office. Canvas-lined suits, hand-finished sherwanis and shirts cut to your measurements.", "11:00", "20:00", "Monday to Sunday"},
            {"Suma Rao", "tailor3@techvastra.com", "9876500013", "Dulapally", "Threads and Needles", "Shop 7, Dulapally Main Road", "8", "4.7", "276",
                "Kurti,Salwar suit,Blouse,Alterations", "Everyday and festive wear for women. Quick turnaround on kurtis, salwar suits and blouses without compromising on finish.", "09:30", "18:30", "Monday to Saturday"},
            {"Venkat Naidu", "tailor4@techvastra.com", "9876500014", "Secunderabad", "Classic Tailors", "Near Secunderabad Railway Station", "20", "4.6", "890",
                "Shirt,Trouser,Uniform,Alterations", "Twenty years in Secunderabad. Shirts, trousers and school or office uniforms in bulk, plus all kinds of alterations.", "10:00", "21:00", "Monday to Saturday"},
            {"Farhana Begum", "tailor5@techvastra.com", "9876500015", "Suchitra", "Silk and Zari Designers", "Suchitra Circle Main Road", "10", "4.8", "338",
                "Bridal blouse,Lehenga,Gown,Designer wear", "Designer bridal wear with zari, aari and stone work. Bring a reference photo and we will recreate it on your fabric.", "11:00", "19:00", "Tuesday to Sunday"},
            {"Ravi Teja", "tailor6@techvastra.com", "9876500016", "Jeedimetla", "Quick Fit Alterations", "Opposite Bus Stop, Jeedimetla", "6", "4.5", "190",
                "Alterations,Kurta,Pyjama,Blouse", "Neighbourhood tailor for fast alterations, kurtas and simple blouses. Most small jobs are ready in two days.", "09:00", "20:00", "Monday to Saturday"},
            {"Kavya Shetty", "tailor7@techvastra.com", "9876500017", "Alwal", "Kavya Couture", "Near Alwal Bus Stand", "9", "4.7", "245",
                "Bridal blouse,Lehenga,Gown,Saree fall", "Bridal and festive tailoring in Alwal, with fittings arranged around your schedule.", "10:00", "19:00", "Monday to Saturday"},
            {"Arun Kumar", "tailor8@techvastra.com", "9876500018", "Ram Nagar", "Ram Nagar Gents Tailoring", "Main Road, Ram Nagar", "14", "4.6", "402",
                "Suits,Shirt,Blazer,Trouser", "Made to measure formal wear with a five day standard turnaround.", "10:30", "20:30", "Monday to Saturday"},
            {"Padma Lakshmi", "tailor9@techvastra.com", "9876500019", "Bowrampet", "Padma Fashion Hub", "Opposite Bowrampet Cross Roads", "11", "4.8", "310",
                "Blouse,Kurti,Salwar suit,Lehenga", "Ladies tailoring in Bowrampet for blouses, kurtis, salwar suits and lehengas, with free home pickup for bulk orders.", "10:00", "19:30", "Monday to Saturday"},
            {"Shaik Rahim", "tailor10@techvastra.com", "9876500020", "Shapur Nagar", "Shapur Nagar Tailors", "Shapur Nagar Main Road", "7", "4.5", "215",
                "Shirt,Kurta,Pyjama,Alterations", "Dependable gents and family tailoring with two day alterations and festive kurta sets.", "09:30", "20:00", "Monday to Saturday"}
        };

        int idx = 0;
        User firstTailor = null;
        for (String[] r : t) {
            User u = user("TAILOR", r[0], r[1], r[2], r[3], hash);
            if (firstTailor == null) firstTailor = u;
            TailorProfile p = new TailorProfile();
            p.userId = u.id;
            p.shopName = r[4];
            p.address = r[5] + ", Hyderabad";
            p.experienceYears = Integer.parseInt(r[6]);
            p.rating = Double.parseDouble(r[7]);
            p.completedOrders = Integer.parseInt(r[8]);
            p.specialties = r[9];
            p.bio = r[10];
            p.openTime = r[11];
            p.closeTime = r[12];
            p.workingDays = r[13];
            profiles.save(p);

            String[] specs = r[9].split(",");
            for (int k = 0; k < 6; k++) {
                GalleryImage g = new GalleryImage();
                g.tailorId = u.id;
                String spec = specs[k % specs.length].trim();
                g.url = "/gallery/" + styleOf(spec) + "-" + (((k + idx) % 3) + 1) + ".svg";
                g.caption = spec;
                gallery.save(g);
            }

            LocalDate today = LocalDate.now();
            for (int i = 0; i < 45; i++) {
                LocalDate d = today.plusDays(i);
                if (d.getDayOfWeek() == DayOfWeek.SUNDAY) continue;
                if ((i + idx) % 6 == 0) continue;
                if (idx == 3 && i < 6) continue;   // Classic Tailors is fully booked for the next few days
                FreeDate f = new FreeDate();
                f.tailorId = u.id;
                f.freeDate = d;
                freeDates.save(f);
            }
            idx++;
        }

        // Demo orders for the first customer with the first tailor
        OrderRequest a = new OrderRequest();
        a.customerId = customer.id;
        a.tailorId = firstTailor.id;
        a.garment = "Saree blouse";
        a.notes = "Boat neck with deep back and tassels. Please keep sleeves elbow length.";
        a.fabricDetails = "Maroon raw silk, 1 metre, with a contrast gold border.";
        a.measurements = "Bust 36, waist 32, shoulder 14, sleeve 12 inches.";
        a.dueDate = LocalDate.now().plusDays(6);
        a.status = "ACCEPTED";
        a.stage = "Cutting done";
        a.createdAt = LocalDateTime.now().minusDays(2);
        orders.save(a);
        String[] done = {"Request sent", "Order accepted", "Measurements taken", "Fabric received", "Cutting done"};
        for (int i = 0; i < done.length; i++) {
            OrderUpdate u = new OrderUpdate();
            u.orderId = a.id;
            u.stage = done[i];
            u.note = "";
            u.createdAt = LocalDateTime.now().minusDays(2).plusHours(i * 7L);
            updates.save(u);
        }

        OrderRequest b = new OrderRequest();
        b.customerId = customer.id;
        b.tailorId = firstTailor.id;
        b.garment = "Bridal blouse";
        b.notes = "Heavy aari work on the back and sleeves. Reference design will be shared at the first fitting.";
        b.fabricDetails = "Pink and gold pattu silk, 1.5 metres.";
        b.measurements = "Same measurements as the saree blouse order.";
        b.dueDate = LocalDate.now().plusDays(10);
        b.status = "REQUESTED";
        b.stage = "Request sent";
        b.createdAt = LocalDateTime.now().minusHours(3);
        orders.save(b);
        OrderUpdate ub = new OrderUpdate();
        ub.orderId = b.id;
        ub.stage = "Request sent";
        ub.note = "Order request sent to Meera Boutique Studio";
        ub.createdAt = b.createdAt;
        updates.save(ub);

        Notification n = new Notification();
        n.userId = firstTailor.id;
        n.message = "New request from " + customer.name + ": Bridal blouse, needed by " + b.dueDate;
        n.orderId = b.id;
        n.createdAt = b.createdAt;
        notifications.save(n);
    }
}
