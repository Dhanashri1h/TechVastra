package com.techvastra.repo;

import com.techvastra.model.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderUpdateRepository extends JpaRepository<OrderUpdate, Long> {
    List<OrderUpdate> findByOrderIdOrderByCreatedAtAscIdAsc(Long orderId);
}
