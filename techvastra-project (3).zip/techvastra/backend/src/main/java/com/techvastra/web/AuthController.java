package com.techvastra.web;

import com.techvastra.config.Auth;
import com.techvastra.model.TailorProfile;
import com.techvastra.model.User;
import com.techvastra.repo.TailorProfileRepository;
import com.techvastra.repo.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository users;
    private final TailorProfileRepository profiles;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AuthController(UserRepository users, TailorProfileRepository profiles) {
        this.users = users;
        this.profiles = profiles;
    }

    private static String need(Map<String, String> b, String key, String label) {
        String v = b.get(key);
        if (v == null || v.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, label + " is required");
        return v.trim();
    }

    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody Map<String, String> b) {
        String role = need(b, "role", "Account type").toUpperCase();
        if (!role.equals("CUSTOMER") && !role.equals("TAILOR"))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose customer or tailor");
        String name = need(b, "name", "Full name");
        String email = need(b, "email", "Email").toLowerCase();
        String password = need(b, "password", "Password");
        String mobile = need(b, "mobile", "Mobile number");
        String city = need(b, "city", "City");
        String shop = role.equals("TAILOR") ? need(b, "shopName", "Shop name") : null;
        if (password.length() < 6) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Password must be at least 6 characters");
        if (users.findByEmail(email).isPresent())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "An account with this email already exists. Sign in instead.");

        User u = new User();
        u.role = role;
        u.name = name;
        u.email = email;
        u.passwordHash = encoder.encode(password);
        u.mobile = mobile;
        u.city = city;
        u.token = UUID.randomUUID().toString();
        users.save(u);

        if (role.equals("TAILOR")) {
            TailorProfile p = new TailorProfile();
            p.userId = u.id;
            p.shopName = shop;
            p.address = "";
            p.bio = "";
            p.specialties = "";
            p.experienceYears = 0;
            p.openTime = "10:00";
            p.closeTime = "19:00";
            p.workingDays = "Monday to Saturday";
            p.rating = 0;
            p.completedOrders = 0;
            profiles.save(p);
        }
        return session(u);
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> b) {
        String email = b.getOrDefault("email", "").trim().toLowerCase();
        User u = users.findByEmail(email).orElse(null);
        if (u == null || !encoder.matches(b.getOrDefault("password", ""), u.passwordHash))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Email or password is incorrect");
        u.token = UUID.randomUUID().toString();
        users.save(u);
        return session(u);
    }

    @GetMapping("/me")
    public Map<String, Object> me(HttpServletRequest req) {
        return view(Auth.require(req, null));
    }

    private Map<String, Object> session(User u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("token", u.token);
        m.put("user", view(u));
        return m;
    }

    private Map<String, Object> view(User u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", u.id);
        m.put("role", u.role);
        m.put("name", u.name);
        m.put("email", u.email);
        m.put("mobile", u.mobile);
        m.put("city", u.city);
        if (u.role.equals("TAILOR")) profiles.findByUserId(u.id).ifPresent(p -> m.put("shopName", p.shopName));
        return m;
    }
}
