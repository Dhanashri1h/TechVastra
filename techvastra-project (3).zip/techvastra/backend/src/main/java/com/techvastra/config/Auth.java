package com.techvastra.config;

import com.techvastra.model.User;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public final class Auth {
    private Auth() {}

    public static User require(HttpServletRequest req, String role) {
        User u = (User) req.getAttribute("user");
        if (u == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please sign in to continue");
        if (role != null && !role.equals(u.role))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "This action is not available for your account type");
        return u;
    }
}
