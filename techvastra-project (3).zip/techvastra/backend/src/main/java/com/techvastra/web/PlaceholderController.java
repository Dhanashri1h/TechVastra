package com.techvastra.web;

import java.util.concurrent.TimeUnit;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/** Generates the sample gallery pictures used by the seeded tailors (black, navy and white only). */
@RestController
public class PlaceholderController {
    @GetMapping("/api/placeholder/{label}")
    public ResponseEntity<String> image(@PathVariable String label) {
        String seedPart = label.replaceAll("^.*-(\\d+)$", "$1");
        int seed = seedPart.matches("\\d+") ? Integer.parseInt(seedPart) : 1;
        String text = label.replaceAll("-\\d+$", "").replace('-', ' ').replaceAll("[^A-Za-z ]", "").trim();
        if (text.isEmpty()) text = "Tailoring";
        text = text.substring(0, 1).toUpperCase() + text.substring(1);
        String bg = seed % 2 == 0 ? "#0A2A66" : "#000000";
        String panel = seed % 2 == 0 ? "#000000" : "#0A2A66";
        StringBuilder s = new StringBuilder("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 450'>");
        s.append("<rect width='600' height='450' fill='").append(bg).append("'/>");
        for (int i = 0; i < 14; i++) {
            int y = 20 + i * 32 + (seed * 7) % 20;
            s.append("<line x1='0' y1='").append(y).append("' x2='600' y2='").append(y - 60)
                    .append("' stroke='#FFFFFF' stroke-opacity='0.14' stroke-dasharray='6 9'/>");
        }
        int w = 280 + (seed * 13) % 60;
        int x = (600 - w) / 2;
        s.append("<rect x='").append(x).append("' y='95' width='").append(w).append("' height='260' fill='").append(panel)
                .append("' stroke='#FFFFFF' stroke-width='2' stroke-dasharray='10 7'/>");
        s.append("<text x='300' y='232' text-anchor='middle' font-family='Arial, sans-serif' font-size='26' font-weight='bold' fill='#FFFFFF'>")
                .append(text).append("</text>");
        s.append("<text x='300' y='265' text-anchor='middle' font-family='Arial, sans-serif' font-size='15' fill='#FFFFFF' fill-opacity='0.7'>Sample work ")
                .append(seed).append("</text></svg>");
        return ResponseEntity.ok().contentType(MediaType.valueOf("image/svg+xml"))
                .cacheControl(CacheControl.maxAge(1, TimeUnit.DAYS)).body(s.toString());
    }
}
