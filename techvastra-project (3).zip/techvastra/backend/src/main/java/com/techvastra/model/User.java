package com.techvastra.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String role;            // CUSTOMER or TAILOR
    public String name;
    @Column(unique = true) public String email;
    @JsonIgnore public String passwordHash;
    public String mobile;
    public String city;
    @JsonIgnore public String token;
}
