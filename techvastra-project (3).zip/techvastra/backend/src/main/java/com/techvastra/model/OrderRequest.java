package com.techvastra.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
public class OrderRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public Long customerId;
    public Long tailorId;
    public String garment;
    @Column(length = 2000) public String notes;
    @Column(length = 1500) public String fabricDetails;
    @Column(length = 1500) public String measurements;
    public LocalDate dueDate;
    public String audioUrl;
    public String status;   // REQUESTED, ACCEPTED, REJECTED, COMPLETED
    public String stage;
    public LocalDateTime createdAt;
}
