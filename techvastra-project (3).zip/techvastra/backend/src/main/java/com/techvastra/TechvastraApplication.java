package com.techvastra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechvastraApplication {
    public static void main(String[] args) {
        SpringApplication.run(TechvastraApplication.class, args);
    }
}
