package com.techvastra.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "free_dates", uniqueConstraints = @UniqueConstraint(columnNames = {"tailorId", "freeDate"}))
public class FreeDate {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public Long tailorId;
    public LocalDate freeDate;
}
