package com.techvastra.config;

import com.techvastra.model.User;
import com.techvastra.repo.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {
    private final UserRepository users;

    public AuthInterceptor(UserRepository users) {
        this.users = users;
    }

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) throws Exception {
        if ("OPTIONS".equalsIgnoreCase(req.getMethod())) return true;
        String h = req.getHeader("Authorization");
        if (h != null && h.startsWith("Bearer ")) {
            User u = users.findByToken(h.substring(7).trim()).orElse(null);
            if (u != null) {
                req.setAttribute("user", u);
                return true;
            }
        }
        res.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Please sign in to continue");
        return false;
    }
}
