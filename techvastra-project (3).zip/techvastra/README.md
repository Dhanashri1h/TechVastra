# Techvastra

Find a tailor in your city, request an order, and follow every stitching stage.

Stack: React (Vite), Spring Boot 3 (Java 17), MySQL 8. The chatbot is an agent that reads the request, searches tailors, checks their calendars and ranks them.

## What you need installed

- Java 17 or newer (JDK)
- Maven 3.9 or newer
- Node.js 18 or newer
- MySQL 8 running on port 3306

## Run it

1. **Database.** Nothing to create by hand. The backend creates the `techvastra` database and all tables on first start.
   If your MySQL user is not `root` / `root`, open `backend/src/main/resources/application.properties` and change the username and password, or set the `DB_USER` and `DB_PASSWORD` environment variables.

2. **Backend** (terminal 1):
   ```
   cd backend
   mvn spring-boot:run
   ```
   Wait for "Started TechvastraApplication". Demo data is loaded automatically on the first run.

3. **Frontend** (terminal 2):
   ```
   cd frontend
   npm install
   npm run dev
   ```
   Open http://localhost:5173

## Demo accounts (password for all: `password123`)

| Role | Email | Area |
|---|---|---|
| Customer | customer@techvastra.com | Kompally |
| Customer | customer2@techvastra.com | Alwal |
| Tailor | tailor1@techvastra.com (Meera Boutique Studio) | Kompally |
| Tailor | tailor2@techvastra.com (Royal Stitch House) | Hitech City |
| Tailor | tailor3@techvastra.com (Threads and Needles) | Dulapally |
| Tailor | tailor4@techvastra.com (Classic Tailors) | Secunderabad |
| Tailor | tailor5@techvastra.com (Silk and Zari Designers) | Suchitra |
| Tailor | tailor6@techvastra.com (Quick Fit Alterations) | Jeedimetla |
| Tailor | tailor7@techvastra.com (Kavya Couture) | Alwal |
| Tailor | tailor8@techvastra.com (Ram Nagar Gents Tailoring) | Ram Nagar |
| Tailor | tailor9@techvastra.com (Padma Fashion Hub) | Bowrampet |
| Tailor | tailor10@techvastra.com (Shapur Nagar Tailors) | Shapur Nagar |

Areas, not cities: everyone registers with a Hyderabad area. The assistant finds tailors within 20 km of the customer's area and ranks nearer ones higher. Customers can also name another area in the chat, for example "in Hitech City".

Classic Tailors (tailor4) is fully booked for the next six days, so a short deadline shows how the assistant filters by calendar.

### Already ran an older version? Reload the demo data once

The demo data only loads on an empty database. To load the new areas and gallery images, set `techvastra.reseed=${RESEED:false}` to `true` in `application.properties`, start the backend once, then set it back to `false`. (Or run `DROP DATABASE techvastra;` in MySQL.) This deletes existing data.

### Gallery images

Each seeded tailor has six stored images in `frontend/public/gallery`. Tailors can add real photos from Profile and calendar, then Add photo.

## Try the full flow

1. Sign in as `customer@techvastra.com`. In the chat type: `I need a bridal blouse within 4 days, the best tailor near me`.
2. Open a tailor profile: gallery, experience, address, order receiving hours, availability calendar.
3. Choose Request an order. Pick a free date, fill in fabric and measurements, optionally record a voice note, and send.
4. In another browser window sign in as `tailor1@techvastra.com`. The request appears under Requests with all notes and the voice note, and a notification pops up.
5. The tailor accepts. The customer is notified and can now see the tailor's contact number.
6. The tailor updates the stage (measurements, cutting, stitching, threading and finishing, ready) and finally ends the order. The customer is notified at every step and sees the progress bar and history.
7. Tailors manage their gallery, details and free dates under Profile and calendar.

## The chatbot agent

`backend/src/main/java/com/techvastra/service/ChatAgent.java`

1. Understands the garment, the deadline and the area from the message (and remembers them across follow-up messages).
2. Tool: finds tailors within 20 km of the customer's area.
3. Tool: checks each tailor's calendar for a free date before the deadline.
4. Tool: ranks by availability, specialty match, rating and experience.
5. Replies with the ranked tailors and lists the steps it took.

Optional: to let Claude read free-form requests, set the `ANTHROPIC_API_KEY` environment variable before starting the backend. Without it, the built-in parser is used and everything still works.

## Project structure

```
techvastra/
  backend/    Spring Boot API (config, model, repo, service, web)
  frontend/   React app (pages, components, styles.css)
  database/   init.sql (optional)
```

Uploaded gallery photos and voice notes are stored in `backend/uploads`.

## Troubleshooting

- **Access denied for user root**: fix the MySQL username or password as described in step 1.
- **Port 8080 or 5173 in use**: change `server.port` in `application.properties`, or the port in `frontend/vite.config.js` (and the proxy target).
- **Microphone does not record**: allow microphone access in the browser. It works on `localhost` and on HTTPS.
- **Want fresh demo data**: drop the database (`DROP DATABASE techvastra;`) and restart the backend.
